package com.mratubhayas.app.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.*
import com.mratubhayas.app.service.DhyanNotificationHelper
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(prefs: AppPreferences) {
    val context = LocalContext.current
    val powerManager = remember { context.getSystemService(Context.POWER_SERVICE) as PowerManager }
    val dhyanWakeLock = remember {
        powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MratuBhayas:DhyanSessionLock")
    }

    // Live Clock Ticker
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now)
            currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(now)
            delay(1000L)
        }
    }

    // Permission launcher for POST_NOTIFICATIONS
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    fun checkAndRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // ================= 1. DHYAN STATE =================
    var dhyanRunning by remember { mutableStateOf(false) }
    var dhyanTargetSec by remember { mutableIntStateOf(prefs.getDhyanDurationSec()) }
    var dhyanElapsedSec by remember { mutableIntStateOf(0) }
    var showDhyanDialog by remember { mutableStateOf(false) }
    var showDhyanTimeFeedDialog by remember { mutableStateOf(false) }
    var dhyanDismissOpt by remember { mutableStateOf(prefs.getDhyanDismissOption()) }
    var dhyanToneUri by remember { mutableStateOf(prefs.getDhyanToneUri()) }
    var dhyanToneIdx by remember { mutableIntStateOf(prefs.getDhyanToneIndex()) }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            dhyanToneUri = uri?.toString()
            prefs.setDhyanToneUri(dhyanToneUri)
        }
    }

    // Dhyan Runner: Holds WakeLock so screen-off / minimize never stops timer!
    LaunchedEffect(dhyanRunning) {
        if (dhyanRunning) {
            checkAndRequestNotificationPermission()
            dhyanElapsedSec = 0
            if (!dhyanWakeLock.isHeld) {
                dhyanWakeLock.acquire((dhyanTargetSec + 60) * 1000L)
            }
            prefs.scheduleDhyanAlarm(dhyanTargetSec) // Exact hardware alarm clock
            DhyanNotificationHelper.updateDhyanNotification(context, dhyanElapsedSec, dhyanTargetSec)

            while (dhyanRunning && dhyanElapsedSec < dhyanTargetSec) {
                delay(1000L)
                dhyanElapsedSec += 1
                DhyanNotificationHelper.updateDhyanNotification(context, dhyanElapsedSec, dhyanTargetSec)
            }

            if (dhyanRunning && dhyanElapsedSec >= dhyanTargetSec) {
                dhyanRunning = false
                DhyanNotificationHelper.cancelDhyanNotification(context)
                if (dhyanWakeLock.isHeld) dhyanWakeLock.release()

                // Launch Lock-Screen Alert with Ant Running circle and Tone
                val intent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", "Dhyan Meditation Completed!")
                    putExtra("TYPE", "DHYAN")
                    putExtra("DISMISS_OPT", dhyanDismissOpt)
                    putExtra("TONE_URI", dhyanToneUri)
                    putExtra("TONE_IDX", dhyanToneIdx)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                context.startActivity(intent)
            }
        } else {
            prefs.cancelDhyanAlarm()
            DhyanNotificationHelper.cancelDhyanNotification(context)
            if (dhyanWakeLock.isHeld) dhyanWakeLock.release()
        }
    }

    // ================= 2. KRIYA YOGA (BOX PRANAYAMA) STATE =================
    var kriyaRunning by remember { mutableStateOf(false) }
    var kriyaInhaleSec by remember { mutableIntStateOf(prefs.getKriyaInhaleSec()) }
    var kriyaHoldInSec by remember { mutableIntStateOf(prefs.getKriyaHoldInSec()) }
    var kriyaExhaleSec by remember { mutableIntStateOf(prefs.getKriyaExhaleSec()) }
    var kriyaHoldOutSec by remember { mutableIntStateOf(prefs.getKriyaHoldOutSec()) }
    var kriyaPhase by remember { mutableIntStateOf(0) }
    var kriyaSecLeft by remember { mutableIntStateOf(4) }
    var kriyaCycles by remember { mutableIntStateOf(0) }
    var showKriyaDialog by remember { mutableStateOf(false) }

    val phaseNames = listOf("INHALE", "HOLD IN", "EXHALE", "HOLD OUT")

    // Animated Breathing Scale: Visible & Pulsing directly on the card!
    val targetScale = when (kriyaPhase) {
        0 -> 1.4f // Inhale expands
        1 -> 1.4f // Hold In
        2 -> 0.85f // Exhale contracts
        else -> 0.85f // Hold Out
    }
    val animatedKriyaScale by animateFloatAsState(
        targetValue = if (kriyaRunning) targetScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (kriyaRunning) {
                when (kriyaPhase) {
                    0 -> kriyaInhaleSec * 1000
                    1 -> kriyaHoldInSec * 1000
                    2 -> kriyaExhaleSec * 1000
                    else -> kriyaHoldOutSec * 1000
                }
            } else 400,
            easing = FastOutSlowInEasing
        ),
        label = "KriyaBreathingScale"
    )

    LaunchedEffect(kriyaRunning) {
        if (kriyaRunning) {
            kriyaPhase = 0
            kriyaCycles = 0
            while (kriyaRunning) {
                val durations = listOf(kriyaInhaleSec, kriyaHoldInSec, kriyaExhaleSec, kriyaHoldOutSec)
                val curDur = durations[kriyaPhase].coerceAtLeast(1)
                NokiaToneEngine.playBeep(440 + (kriyaPhase * 220), 80)
                for (s in curDur downTo 1) {
                    if (!kriyaRunning) break
                    kriyaSecLeft = s
                    delay(1000L)
                }
                if (kriyaPhase == 3) kriyaCycles += 1
                kriyaPhase = (kriyaPhase + 1) % 4
            }
        }
    }

    // ================= 3. SANSKAR STATE =================
    var sanskarList by remember { mutableStateOf(prefs.getSanskarList()) }
    var sanskarToDelete by remember { mutableStateOf<SanskarItem?>(null) }
    var showSanskarDialog by remember { mutableStateOf(false) }
    var showAddSanskarDialog by remember { mutableStateOf(false) }
    var showSanskarSettingsDialog by remember { mutableStateOf(false) }
    var sanskarDismissOpt by remember { mutableStateOf(prefs.getSanskarDismissOption()) }
    var sanskarStartHour by remember { mutableStateOf(prefs.getSanskarStartHour()) }
    var sanskarStartMin by remember { mutableStateOf(prefs.getSanskarStartMinute()) }
    var sanskarEndHour by remember { mutableStateOf(prefs.getSanskarEndHour()) }
    var sanskarEndMin by remember { mutableStateOf(prefs.getSanskarEndMinute()) }
    var sanskarVolume by remember { mutableStateOf<Float>(prefs.getSanskarVolume()) }
    var sanskarToneUri by remember { mutableStateOf(prefs.getSanskarToneUri()) }
    var sanskarToneIdx by remember { mutableStateOf(prefs.getSanskarToneIndex()) }

    val sanskarRingtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI) as? Uri
            }
            sanskarToneUri = uri?.toString()
            prefs.setSanskarToneUri(sanskarToneUri)
        }
    }

    // ================= OTHER SHEETS STATE =================
    var showSankalpSheet by remember { mutableStateOf(false) }
    var showAlarmsSheet by remember { mutableStateOf(false) }
    var showNotesSheet by remember { mutableStateOf(false) }
    var showLogsSheet by remember { mutableStateOf(false) }
    var showPlannerSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    var niyamList by remember { mutableStateOf(prefs.getNiyamList()) }
    var trackerList by remember { mutableStateOf(prefs.getTrackerList()) }
    val currentEpochDay = System.currentTimeMillis() / (86400 * 1000L)

    // DISTINCT VIBRANT TILE COLORS FOR EACH CARD
    val colorGreen = Color(0xFF10B981)   // Tile 1: Dhyan (Emerald Green)
    val colorYellow = Color(0xFFFFB300)  // Tile 2: Kriya Yog (Golden Yellow)
    val colorCyan = Color(0xFF00E5FF)    // Tile 3: Sanskar (Vivid Cyan)
    val colorOrange = Color(0xFFFF5722)  // Tile 4: Sankalp (Deep Orange)
    val colorRed = Color(0xFFEF4444)     // Tile 5: Alarm (Bright Red)
    val colorAmber = Color(0xFFF59E0B)   // Tile 6: Notes (Amber Gold)
    val colorPurple = Color(0xFF8B5CF6)  // Tile 7: Logs (Royal Purple)
    val colorTeal = Color(0xFF14B8A6)    // Tile 8: Planner (Teal)
    val colorLime = Color(0xFF84CC16)    // Tile 9: Settings (Lime Green)
    val colorBg = Color(0xFF000000)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colorBg)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        // TOP HEADER: BRANDING & LIVE CLOCK
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp, bottom = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MRATUBHAYAS",
                    color = colorYellow,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { showLogsSheet = true },
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(0xFF1E222B), CircleShape)
                            .border(1.dp, colorGreen.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "Logs",
                            tint = colorGreen,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    IconButton(
                        onClick = { showSettingsSheet = true },
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color(0xFF1E222B), CircleShape)
                            .border(1.dp, colorLime.copy(alpha = 0.5f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = colorLime,
                            modifier = Modifier.size(19.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = currentDate.uppercase(),
                    color = Color(0xFFA0AEC0),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = currentTime,
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // ================= 2-COLUMN PROMINENT GRID (LARGE READABLE FONTS) =================
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // TILE 1: DHYAN (PROMINENT LARGE CARD)
            item {
                ProminentDashboardCard(
                    title = "Dhyan",
                    badge = "MEDITATION",
                    subtitle = if (!dhyanRunning) "Target: ${formatDurationSec(dhyanTargetSec)}" else "Running: ${DhyanNotificationHelper.formatSeconds(dhyanElapsedSec)}",
                    accentColor = colorGreen,
                    icon = Icons.Default.PlayArrow,
                    isTwoAction = true,
                    action1Icon = if (dhyanRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (dhyanRunning) "STOP" else "PLAY",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SETTING",
                    onAction1 = { dhyanRunning = !dhyanRunning },
                    onAction2 = { showDhyanDialog = true },
                    onCardClick = { showDhyanDialog = true },
                    isRunning = dhyanRunning,
                    centerContent = {
                        if (dhyanRunning) {
                            AnimatedDhyanAura(color = colorGreen, elapsedStr = DhyanNotificationHelper.formatSeconds(dhyanElapsedSec))
                        } else {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Ready", color = colorGreen.copy(alpha = 0.8f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                Text(formatDurationSec(dhyanTargetSec), color = colorYellow, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                )
            }

            // TILE 2: KRIYA YOG (WITH LIVE EXPANDING/CONTRACTING BREATHING ANIMATION)
            item {
                ProminentDashboardCard(
                    title = "Kriya Yog",
                    badge = "PRANAYAMA",
                    subtitle = if (!kriyaRunning) "Box: ${kriyaInhaleSec}s-${kriyaHoldInSec}s-${kriyaExhaleSec}s-${kriyaHoldOutSec}s" else "Round: $kriyaCycles",
                    accentColor = colorYellow,
                    icon = Icons.Default.Refresh,
                    isTwoAction = true,
                    action1Icon = if (kriyaRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (kriyaRunning) "STOP" else "PLAY",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SETTING",
                    onAction1 = { kriyaRunning = !kriyaRunning },
                    onAction2 = { showKriyaDialog = true },
                    onCardClick = { showKriyaDialog = true },
                    isRunning = kriyaRunning,
                    centerContent = {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (kriyaRunning) phaseNames[kriyaPhase] else "4S BOX",
                                color = if (kriyaRunning) colorYellow else Color(0xFFA0AEC0),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .scale(animatedKriyaScale)
                                    .background(colorYellow.copy(alpha = if (kriyaRunning) 0.28f else 0.12f), CircleShape)
                                    .border(1.5.dp, if (kriyaRunning) colorYellow else colorYellow.copy(alpha = 0.4f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (kriyaRunning) "${kriyaSecLeft}s" else "GO",
                                    color = if (kriyaRunning) Color.White else colorYellow,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                )
            }

            // TILE 3: SANSKAR (SPAN 2 COLUMNS, BELL ICON, ENGLISH SANSKAR, ISOLATED SCROLLABLE LIST, NO CARD CLICK)
            item(span = { GridItemSpan(2) }) {
                val sanskarScrollState = rememberScrollState()
                val stopParentScrollConnection = remember {
                    object : NestedScrollConnection {
                        override fun onPostScroll(
                            consumed: Offset,
                            available: Offset,
                            source: NestedScrollSource
                        ): Offset {
                            // Absorb remaining scroll delta so parent grid does NOT scroll
                            return available
                        }
                        override suspend fun onPostFling(
                            consumed: Velocity,
                            available: Velocity
                        ): Velocity {
                            return available
                        }
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF12151B)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(235.dp)
                        .border(1.5.dp, colorCyan.copy(alpha = 0.85f), RoundedCornerShape(20.dp)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp)
                    ) {
                        // TOP ROW: "SANSKAR" IN ENGLISH + ADD (+) + SETTING GEAR
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(colorCyan.copy(alpha = 0.22f), RoundedCornerShape(12.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "SANSKAR",
                                        color = colorCyan,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                }
                                Text(
                                    text = "(${sanskarList.count { it.active }}/${sanskarList.size} Active)",
                                    color = Color(0xFFA0AEC0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Add Button (+)
                                Surface(
                                    onClick = { showAddSanskarDialog = true },
                                    shape = CircleShape,
                                    color = colorCyan,
                                    modifier = Modifier.size(34.dp),
                                    shadowElevation = 3.dp
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Add,
                                            contentDescription = "Add Sanskar",
                                            tint = Color.Black,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                // Setting Gear
                                Surface(
                                    onClick = { showSanskarSettingsDialog = true },
                                    shape = CircleShape,
                                    color = Color(0xFFFFB300),
                                    modifier = Modifier.size(34.dp),
                                    shadowElevation = 3.dp
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Settings,
                                            contentDescription = "Sanskar Settings",
                                            tint = Color.Black,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // SCROLLABLE LIST OF SANSKARS: ISOLATED FROM PARENT GRID
                        if (sanskarList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No Sanskar chimes yet. Tap (+) above to add your reminder.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .nestedScroll(stopParentScrollConnection)
                                    .verticalScroll(sanskarScrollState),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                sanskarList.forEach { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF181C26), RoundedCornerShape(10.dp))
                                            .border(1.dp, if (item.active) colorCyan.copy(alpha = 0.4f) else Color.DarkGray, RoundedCornerShape(10.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.title,
                                                color = if (item.active) Color.White else Color.Gray,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "Every ${item.intervalMin}m • ${formatTimeAmPm(sanskarStartHour, sanskarStartMin)} - ${formatTimeAmPm(sanskarEndHour, sanskarEndMin)}",
                                                color = if (item.active) colorCyan else Color.DarkGray,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // ON / OFF TOGGLE SWITCH
                                            Switch(
                                                checked = item.active,
                                                onCheckedChange = { isChecked ->
                                                    val updated = sanskarList.map {
                                                        if (it.id == item.id) it.copy(active = isChecked) else it
                                                    }.toMutableList()
                                                    sanskarList = updated
                                                    prefs.saveSanskarList(updated)
                                                    if (isChecked) {
                                                        prefs.scheduleSanskarAlarm(item.copy(active = true))
                                                    } else {
                                                        prefs.cancelSanskarAlarm(item)
                                                    }
                                                },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = colorCyan,
                                                    checkedTrackColor = colorCyan.copy(alpha = 0.4f),
                                                    uncheckedThumbColor = Color.Gray,
                                                    uncheckedTrackColor = Color(0xFF232733)
                                                ),
                                                modifier = Modifier.scale(0.8f)
                                            )

                                            // DELETE TRASH BIN ICON (ASKS FOR USER CONFIRMATION)
                                            IconButton(
                                                onClick = { sanskarToDelete = item },
                                                modifier = Modifier.size(30.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Delete",
                                                    tint = Color(0xFFEF4444),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // TILE 4: SANKALP (VIBRANT ORANGE BORDER)
            item {
                ProminentDashboardCard(
                    title = "Sankalp",
                    badge = "DISCIPLINE",
                    subtitle = "Daily Resolutions",
                    accentColor = colorOrange,
                    icon = Icons.Default.Check,
                    isTwoAction = true,
                    action1Icon = Icons.Default.Check,
                    action1Label = "CHECK",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SETTING",
                    onAction1 = {
                        val updated = trackerList.map {
                            if (it.lastCheckedEpochDay != currentEpochDay) {
                                it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                            } else it
                        }
                        trackerList = updated.toMutableList()
                        prefs.saveTrackerList(updated)
                    },
                    onAction2 = { showSankalpSheet = true },
                    onCardClick = { showSankalpSheet = true }
                )
            }

            // TILE 5: ALARM (BRIGHT RED BORDER)
            item {
                ProminentDashboardCard(
                    title = "Alarm",
                    badge = "ALERTS",
                    subtitle = "${niyamList.count { it.active }} Set Alarms",
                    accentColor = colorRed,
                    icon = Icons.Default.Notifications,
                    isTwoAction = false,
                    onCardClick = { showAlarmsSheet = true }
                )
            }

            // TILE 6: NOTES (AMBER GOLD BORDER, SPAN 2)
            item(span = { GridItemSpan(2) }) {
                ProminentDashboardCard(
                    title = "Notes",
                    badge = "DIARY",
                    subtitle = "${prefs.getNotes().size} Saved Notes",
                    accentColor = colorAmber,
                    icon = Icons.Default.Edit,
                    isTwoAction = false,
                    onCardClick = { showNotesSheet = true }
                )
            }

            // TILE 7: PLANNER (BRIGHT TEAL BORDER, SPAN 2)
            item(span = { GridItemSpan(2) }) {
                ProminentDashboardCard(
                    title = "Planner",
                    badge = "SCHEDULE",
                    subtitle = "Daily Schedules & Events",
                    accentColor = colorTeal,
                    icon = Icons.Default.DateRange,
                    isTwoAction = false,
                    onCardClick = { showPlannerSheet = true }
                )
            }
        }
    }

    // =========================================================================
    // MODAL DIALOGS
    // =========================================================================

    // 1. DHYAN FULL CONTROLS DIALOG (10 SEC TO 12 HOURS FREE FLOW + CLICK TO FEED)
    if (showDhyanDialog) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")
        val nokiaMelodyNames = listOf("Nokia Intro", "SMS Special", "Nostalgia", "William Tell", "Polka")

        AlertDialog(
            onDismissRequest = { showDhyanDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Dhyan Meditation Settings", color = colorGreen, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    IconButton(onClick = { showDhyanDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        text = "Target Duration (Click big time below to type):",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )

                    // Big Clickable Center Time Display (Click to direct feed!)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF141820), RoundedCornerShape(16.dp))
                            .border(1.5.dp, colorGreen, RoundedCornerShape(16.dp))
                            .clickable { showDhyanTimeFeedDialog = true }
                            .padding(vertical = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = DhyanNotificationHelper.formatSeconds(dhyanTargetSec),
                                color = colorGreen,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "👆 Tap here to type exact value (10s - 12h)",
                                color = colorYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Stepper row for quick adjustments
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec - 60).coerceAtLeast(10)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("-1m", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec - 300).coerceAtLeast(10)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("-5m", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec + 300).coerceAtMost(12 * 3600)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+5m", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec + 1800).coerceAtMost(12 * 3600)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+30m", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Auto-Dismiss Duration (OFF, 10s, 20s, 40s, 1m)
                    Text("Auto-Dismiss Alert Timeout:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = dhyanDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    dhyanDismissOpt = opt
                                    prefs.setDhyanDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = colorGreen,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                    Text(
                        text = if (dhyanDismissOpt == "OFF") "OFF: Alert rings continuously until user manually dismisses" else "Auto shuts off after $dhyanDismissOpt",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    // Alert Sound Selection
                    Text("Alert Sound Selection:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        nokiaMelodyNames.forEachIndexed { idx, name ->
                            val isSelected = dhyanToneIdx == idx && dhyanToneUri == null
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        dhyanToneIdx = idx
                                        dhyanToneUri = null
                                        prefs.setDhyanToneIndex(idx)
                                        prefs.setDhyanToneUri(null)
                                        NokiaToneEngine.playTone(idx, loop = false)
                                    }
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = if (isSelected) colorGreen else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = colorGreen, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    // Phone Storage Audio Picker
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Alert Sound")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            }
                            ringtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (dhyanToneUri != null) "Custom Audio Selected" else "Choose from Phone Storage",
                            color = colorYellow,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dhyanRunning = !dhyanRunning
                        showDhyanDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (dhyanRunning) Color(0xFFFF5252) else colorGreen
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (dhyanRunning) "Stop Session" else "Start Dhyan", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 1B. DHYAN TIME DIRECT FEED DIALOG (10 SEC TO 12 HOURS)
    if (showDhyanTimeFeedDialog) {
        var inputHours by remember { mutableIntStateOf(dhyanTargetSec / 3600) }
        var inputMins by remember { mutableIntStateOf((dhyanTargetSec % 3600) / 60) }
        var inputSecs by remember { mutableIntStateOf(dhyanTargetSec % 60) }

        AlertDialog(
            onDismissRequest = { showDhyanTimeFeedDialog = false },
            title = {
                Text("Feed Exact Meditation Time", color = colorGreen, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Select any duration between 10 Seconds and 12 Hours:", color = Color.Gray, fontSize = 12.sp)

                    // Hours Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Hours (0 - 12):", color = Color.White, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputHours > 0) inputHours-- }, shape = RoundedCornerShape(8.dp)) { Text("-") }
                            Text("  $inputHours h  ", color = colorYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Button(onClick = { if (inputHours < 12) inputHours++ }, shape = RoundedCornerShape(8.dp)) { Text("+") }
                        }
                    }

                    // Minutes Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Minutes (0 - 59):", color = Color.White, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputMins > 0) inputMins-- }, shape = RoundedCornerShape(8.dp)) { Text("-") }
                            Text("  $inputMins m  ", color = colorYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Button(onClick = { if (inputMins < 59) inputMins++ }, shape = RoundedCornerShape(8.dp)) { Text("+") }
                        }
                    }

                    // Seconds Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Seconds (0 - 59):", color = Color.White, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputSecs >= 5) inputSecs -= 5 else inputSecs = 0 }, shape = RoundedCornerShape(8.dp)) { Text("-5") }
                            Text("  $inputSecs s  ", color = colorYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Button(onClick = { if (inputSecs <= 54) inputSecs += 5 else inputSecs = 59 }, shape = RoundedCornerShape(8.dp)) { Text("+5") }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val totalSec = (inputHours * 3600 + inputMins * 60 + inputSecs).coerceIn(10, 12 * 3600)
                        dhyanTargetSec = totalSec
                        prefs.setDhyanDurationSec(totalSec)
                        showDhyanTimeFeedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colorGreen),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Apply Time", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDhyanTimeFeedDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 2. KRIYA YOGA BREATHING DIALOG
    if (showKriyaDialog) {
        AlertDialog(
            onDismissRequest = { showKriyaDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Kriya Yog Pranayama", color = colorYellow, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    IconButton(onClick = { showKriyaDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Visual pulsing aura
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(130.dp)
                                .scale(animatedKriyaScale)
                                .background(colorYellow.copy(alpha = 0.18f), CircleShape)
                                .border(2.dp, colorYellow, CircleShape)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (kriyaRunning) phaseNames[kriyaPhase] else "READY",
                                color = colorYellow,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (kriyaRunning) {
                                Text(
                                    text = "${kriyaSecLeft}s",
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text("Rounds: $kriyaCycles", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }

                    Text("Breath Phase Timing (Seconds):", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                    KriyaDurationRow("Breath In Time", kriyaInhaleSec) {
                        kriyaInhaleSec = it
                        prefs.setKriyaInhaleSec(it)
                    }
                    KriyaDurationRow("Hold In Time", kriyaHoldInSec) {
                        kriyaHoldInSec = it
                        prefs.setKriyaHoldInSec(it)
                    }
                    KriyaDurationRow("Breath Out Time", kriyaExhaleSec) {
                        kriyaExhaleSec = it
                        prefs.setKriyaExhaleSec(it)
                    }
                    KriyaDurationRow("Hold Out Time", kriyaHoldOutSec) {
                        kriyaHoldOutSec = it
                        prefs.setKriyaHoldOutSec(it)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        kriyaRunning = !kriyaRunning
                        showKriyaDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (kriyaRunning) Color(0xFFFF5252) else colorYellow
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (kriyaRunning) "Stop Kriya" else "Start Kriya", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 3. SANSKAR CHIMES MANAGEMENT DIALOG (MULTIPLE SANSKARS LIST)
    if (showSanskarDialog) {
        AlertDialog(
            onDismissRequest = { showSanskarDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sanskar Reminders", color = colorGreen, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Row {
                        IconButton(onClick = { showAddSanskarDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = colorGreen)
                        }
                        IconButton(onClick = { showSanskarSettingsDialog = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = colorYellow)
                        }
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Active Window: ${sanskarStartHour}:00 - ${sanskarEndHour}:00 | Dismiss: $sanskarDismissOpt",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )

                    if (sanskarList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No Sanskar chimes created yet.\nTap (+) above to add your interval chime!", color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                        }
                    } else {
                        sanskarList.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF181C26), RoundedCornerShape(12.dp))
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Rings every ${item.intervalMin} minutes", color = colorGreen, fontSize = 12.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        val updated = sanskarList.filter { it.id != item.id }
                                        sanskarList = updated.toMutableList()
                                        prefs.saveSanskarList(updated)
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(20.dp))
                                    }
                                    Switch(
                                        checked = item.active,
                                        onCheckedChange = { active ->
                                            val updated = sanskarList.map {
                                                if (it.id == item.id) it.copy(active = active) else it
                                            }
                                            sanskarList = updated.toMutableList()
                                            prefs.saveSanskarList(updated)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSanskarDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 3B. ADD SANSKAR DIALOG (TITLE + H+/H-/M+/M- + ODOMETER WHEELS + DIRECT NUMERIC FEED)
    if (showAddSanskarDialog) {
        var sTitle by remember { mutableStateOf("") }
        var sHours by remember { mutableIntStateOf(0) }
        var sMinutes by remember { mutableIntStateOf(15) }

        AlertDialog(
            onDismissRequest = { showAddSanskarDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Add New Sanskar", color = colorCyan, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    IconButton(onClick = { showAddSanskarDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    OutlinedTextField(
                        value = sTitle,
                        onValueChange = { sTitle = it },
                        label = { Text("Sanskar Title (e.g. Mindful Chime)") },
                        placeholder = { Text("Breathe & Smile") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        "Set Chime Interval Duration:",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    // 1. ODOMETER WHEELS (HOURS & MINUTES)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Hour Odometer
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("HOURS", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(3.dp))
                            OdometerWheel(
                                value = String.format("%02d", sHours),
                                onUp = { sHours = (sHours + 1).coerceAtMost(12) },
                                onDown = { sHours = (sHours - 1).coerceAtLeast(0) },
                                accentColor = colorCyan
                            )
                        }

                        Text(
                            ":",
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )

                        // Minute Odometer
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("MINUTES", color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(3.dp))
                            OdometerWheel(
                                value = String.format("%02d", sMinutes),
                                onUp = {
                                    if (sMinutes >= 59) {
                                        sMinutes = 0
                                        if (sHours < 12) sHours++
                                    } else sMinutes++
                                },
                                onDown = {
                                    if (sMinutes <= 0) {
                                        if (sHours > 0) {
                                            sHours--
                                            sMinutes = 59
                                        }
                                    } else sMinutes--
                                },
                                accentColor = colorCyan
                            )
                        }
                    }

                    // 2. QUICK STEPPERS: H- / H+ / M- / M+
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { sHours = (sHours - 1).coerceAtLeast(0) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text("H-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { sHours = (sHours + 1).coerceAtMost(12) },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text("H+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                if (sMinutes <= 0) {
                                    if (sHours > 0) { sHours--; sMinutes = 59 }
                                } else sMinutes--
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text("M-", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = {
                                if (sMinutes >= 59) {
                                    sMinutes = 0
                                    if (sHours < 12) sHours++
                                } else sMinutes++
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                        ) {
                            Text("M+", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    // 3. DIRECT FEED NUMERIC INPUTS (HOURS & MINUTES)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = if (sHours == 0) "" else sHours.toString(),
                            onValueChange = { input ->
                                val num = input.filter { it.isDigit() }.toIntOrNull() ?: 0
                                sHours = num.coerceIn(0, 12)
                            },
                            label = { Text("Feed Hours (0-12)", fontSize = 11.sp) },
                            placeholder = { Text("0") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = if (sMinutes == 0) "" else sMinutes.toString(),
                            onValueChange = { input ->
                                val num = input.filter { it.isDigit() }.toIntOrNull() ?: 0
                                sMinutes = num.coerceIn(0, 59)
                            },
                            label = { Text("Feed Minutes (0-59)", fontSize = 11.sp) },
                            placeholder = { Text("15") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // 4. LIVE SUMMARY BADGE
                    val totalIntervalMin = (sHours * 60 + sMinutes).coerceAtLeast(1)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(colorCyan.copy(alpha = 0.15f), RoundedCornerShape(10.dp))
                            .border(1.dp, colorCyan.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Rings Every: ${sHours}h ${sMinutes}m (${totalIntervalMin} Minutes)",
                            color = colorCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val totalIntervalMin = (sHours * 60 + sMinutes).coerceAtLeast(1)
                        if (sTitle.isNotBlank()) {
                            val newItem = SanskarItem(
                                title = sTitle.trim(),
                                intervalMin = totalIntervalMin,
                                active = true,
                                startHour = sanskarStartHour,
                                endHour = sanskarEndHour
                            )
                            val updated = sanskarList.toMutableList().apply { add(newItem) }
                            sanskarList = updated
                            prefs.saveSanskarList(updated)
                            prefs.scheduleSanskarAlarm(newItem)
                            showAddSanskarDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colorCyan),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Create Sanskar", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSanskarDialog = false }) { Text("Cancel", color = Color.Gray) }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 3C. SANSKAR GEAR SETTINGS DIALOG (TONES GALLERY + VOLUME SLIDER + ODOMETER ACTIVE HOURS AM/PM + DISMISS)
    if (showSanskarSettingsDialog) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")
        val melodyNames = listOf("Nokia Intro", "SMS Morse", "Lullaby", "Rossini", "Polka")

        AlertDialog(
            onDismissRequest = { showSanskarSettingsDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sanskar Settings", color = colorCyan, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    IconButton(onClick = { showSanskarSettingsDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // SECTION 1: TONE SELECTION (SYSTEM GALLERY / STORAGE + NOKIA MELODIES)
                    Text("1. Alert Sound & Tones:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    OutlinedButton(
                        onClick = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_NOTIFICATION or RingtoneManager.TYPE_RINGTONE)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Sanskar Tone")
                                sanskarToneUri?.let { putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(it)) }
                            }
                            sanskarRingtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = colorCyan),
                        border = BorderStroke(1.dp, colorCyan.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (sanskarToneUri != null) "✔ Custom Tone Selected (Tap to Change)" else "📁 Choose from Sound Gallery (Phone Tones)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    if (sanskarToneUri != null) {
                        TextButton(
                            onClick = {
                                sanskarToneUri = null
                                prefs.setSanskarToneUri(null)
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Reset to Built-in Melodies", color = Color.Gray, fontSize = 11.sp)
                        }
                    } else {
                        // 8-Bit Built-in Melodies Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            melodyNames.forEachIndexed { idx, name ->
                                val sel = sanskarToneIdx == idx
                                FilterChip(
                                    selected = sel,
                                    onClick = {
                                        sanskarToneIdx = idx
                                        prefs.setSanskarToneIndex(idx)
                                        NokiaToneEngine.volume = sanskarVolume
                                        NokiaToneEngine.playTone(idx, loop = false)
                                    },
                                    label = { Text(name, fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = colorCyan,
                                        selectedLabelColor = Color.Black
                                    )
                                )
                            }
                        }
                    }

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.25f)))

                    // SECTION 2: VOLUME SLIDER
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("2. Alarm Volume: ${(sanskarVolume * 100).toInt()}%", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        TextButton(
                            onClick = {
                                NokiaToneEngine.volume = sanskarVolume
                                NokiaToneEngine.playTone(sanskarToneIdx, loop = false)
                            }
                        ) {
                            Text("Test Tone", color = colorCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Slider(
                        value = sanskarVolume,
                        onValueChange = {
                            sanskarVolume = it
                            prefs.setSanskarVolume(it)
                            NokiaToneEngine.volume = it
                        },
                        valueRange = 0.05f..1f,
                        colors = SliderDefaults.colors(
                            thumbColor = colorCyan,
                            activeTrackColor = colorCyan,
                            inactiveTrackColor = Color(0xFF232733)
                        )
                    )

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.25f)))

                    // SECTION 3: ACTIVE HOURS WITH ODOMETER STEPPERS (AM/PM)
                    Text("3. Active Hours:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)

                    // Start Time Odometer
                    OdometerTimePicker(
                        label = "Start Time:",
                        hour24 = sanskarStartHour,
                        minute = sanskarStartMin,
                        accentColor = colorCyan,
                        onTimeChanged = { h, m ->
                            sanskarStartHour = h
                            sanskarStartMin = m
                            prefs.setSanskarStartHour(h)
                            prefs.setSanskarStartMinute(m)
                        }
                    )

                    // End Time Odometer
                    OdometerTimePicker(
                        label = "End Time:",
                        hour24 = sanskarEndHour,
                        minute = sanskarEndMin,
                        accentColor = colorCyan,
                        onTimeChanged = { h, m ->
                            sanskarEndHour = h
                            sanskarEndMin = m
                            prefs.setSanskarEndHour(h)
                            prefs.setSanskarEndMinute(m)
                        }
                    )

                    Text(
                        text = "Sanskar alarms will only ring between ${formatTimeAmPm(sanskarStartHour, sanskarStartMin)} and ${formatTimeAmPm(sanskarEndHour, sanskarEndMin)} (Quiet at night).",
                        color = colorCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.25f)))

                    // SECTION 4: AUTO-DISMISS ALERT TIMEOUT
                    Text("4. Auto-Dismiss Alert Timeout:", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = sanskarDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    sanskarDismissOpt = opt
                                    prefs.setSanskarDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = colorCyan,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                    Text(
                        text = if (sanskarDismissOpt == "OFF") "OFF: Rings until user manually taps Stop" else "Auto stops ringing after $sanskarDismissOpt",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSanskarSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = colorCyan),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("Save & Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 3D. SANSKAR DELETE CONFIRMATION DIALOG (ASK USER BEFORE DELETING)
    if (sanskarToDelete != null) {
        val target = sanskarToDelete!!
        AlertDialog(
            onDismissRequest = { sanskarToDelete = null },
            title = {
                Text("Delete Sanskar?", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            },
            text = {
                Text("Are you sure you want to delete '${target.title}'?", color = Color.White, fontSize = 14.sp)
            },
            confirmButton = {
                Button(
                    onClick = {
                        val updated = sanskarList.toMutableList()
                        updated.removeAll { it.id == target.id }
                        sanskarList = updated
                        prefs.saveSanskarList(updated)
                        prefs.cancelSanskarAlarm(target)
                        sanskarToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { sanskarToDelete = null }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF181C26)
        )
    }

    // 4. SANKALP DIALOG
    if (showSankalpSheet) {
        AlertDialog(
            onDismissRequest = { showSankalpSheet = false },
            title = { Text("Sankalp Daily Resolutions", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    trackerList.forEach { item ->
                        val isMarkedToday = item.lastCheckedEpochDay == currentEpochDay
                        val totalProgress = if (item.targetDays > 0) item.completedDays.toFloat() / item.targetDays.toFloat() else 0f
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Day ${item.completedDays} of ${item.targetDays}", color = Color.Gray, fontSize = 12.sp)
                                }
                                if (isMarkedToday) {
                                    FilledTonalButton(onClick = {}, enabled = false) {
                                        Text("Done", fontSize = 12.sp)
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            val updated = trackerList.map {
                                                if (it.id == item.id) it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                                                else it
                                            }
                                            trackerList = updated.toMutableList()
                                            prefs.saveTrackerList(updated)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = colorYellow)
                                    ) {
                                        Text("Check", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = totalProgress,
                                modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape),
                                color = colorYellow,
                                trackColor = Color(0xFF262A34)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSankalpSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 5. ALARMS SHEET
    if (showAlarmsSheet) {
        var showAddAlarm by remember { mutableStateOf(false) }
        var newTitle by remember { mutableStateOf("") }
        var newHour by remember { mutableIntStateOf(6) }
        var newMin by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { showAlarmsSheet = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Exact Alarms", color = colorGreen, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { showAddAlarm = !showAddAlarm }) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = colorGreen)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (showAddAlarm) {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Alarm Name") },
                            singleLine = true
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Time: ${String.format(Locale.getDefault(), "%02d:%02d", newHour, newMin)}", color = Color.White)
                            Row {
                                Button(onClick = { newHour = (newHour + 1) % 24 }) { Text("+1h") }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(onClick = { newMin = (newMin + 15) % 60 }) { Text("+15m") }
                            }
                        }
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    val item = NiyamItem(title = newTitle, hour = newHour, minute = newMin, active = true)
                                    val updated = niyamList.toMutableList().apply { add(item) }
                                    niyamList = updated
                                    prefs.saveNiyamList(updated)
                                    newTitle = ""
                                    showAddAlarm = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = colorGreen)
                        ) {
                            Text("Save Alarm", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    }

                    niyamList.forEach { item ->
                        val rh = if (item.hour % 12 == 0) 12 else item.hour % 12
                        val amPm = if (item.hour >= 12) "PM" else "AM"
                        val timeStr = String.format(Locale.getDefault(), "%02d:%02d %s", rh, item.minute, amPm)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(timeStr, color = colorGreen, fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val updated = niyamList.filter { it.id != item.id }
                                    niyamList = updated.toMutableList()
                                    prefs.saveNiyamList(updated)
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                                Switch(
                                    checked = item.active,
                                    onCheckedChange = { active ->
                                        val updated = niyamList.map {
                                            if (it.id == item.id) it.copy(active = active) else it
                                        }
                                        niyamList = updated.toMutableList()
                                        prefs.saveNiyamList(updated)
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAlarmsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 6. NOTES SHEET
    if (showNotesSheet) {
        var notes by remember { mutableStateOf(prefs.getNotes()) }
        var newNoteText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNotesSheet = false },
            title = { Text("Sacred Notes & Diary", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newNoteText,
                        onValueChange = { newNoteText = it },
                        label = { Text("Write reflection...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (newNoteText.isNotBlank()) {
                                val item = NoteItem(text = newNoteText)
                                val updated = notes.toMutableList().apply { add(0, item) }
                                notes = updated
                                prefs.saveNotes(updated)
                                newNoteText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colorYellow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Note", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    notes.take(5).forEach { note ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(note.text, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val updated = notes.filter { it.id != note.id }
                                notes = updated.toMutableList()
                                prefs.saveNotes(updated)
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showNotesSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 7. LOGS SHEET
    if (showLogsSheet) {
        val logs = prefs.getLogs()
        AlertDialog(
            onDismissRequest = { showLogsSheet = false },
            title = { Text("Daily History & Logs", color = colorGreen, fontWeight = FontWeight.Bold) },
            text = {
                if (logs.isEmpty()) {
                    Text("No logs recorded yet.", color = Color.Gray)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        logs.take(8).forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(log.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("${log.timeStr} • ${log.type}", color = Color.Gray, fontSize = 11.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(colorGreen.copy(alpha = 0.2f), CircleShape)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(text = log.status, color = colorGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showLogsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 8. PLANNER SHEET
    if (showPlannerSheet) {
        var plannerEvents by remember { mutableStateOf(prefs.getPlannerEvents()) }
        AlertDialog(
            onDismissRequest = { showPlannerSheet = false },
            title = { Text("Routine & Planner", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (plannerEvents.isEmpty()) {
                        Text("No upcoming events in planner.", color = Color.Gray)
                    } else {
                        plannerEvents.forEach { ev ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ev.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(String.format(Locale.getDefault(), "%02d:%02d", ev.hour, ev.minute), color = colorYellow, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showPlannerSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }

    // 9. APP SETTINGS SHEET
    if (showSettingsSheet) {
        AlertDialog(
            onDismissRequest = { showSettingsSheet = false },
            title = { Text("App Preferences & Controls", color = colorGreen, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Version: 1.3.0 (Themed Green & Yellow Black Edition)", color = Color.Gray, fontSize = 12.sp)

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                        Button(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Enable Lockscreen Popups (Grant Permission)", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                context.startActivity(intent)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Disable Battery Optimization (Background Alarms)", color = Color.White, fontSize = 12.sp)
                    }

                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Manage App Permissions", color = Color.White, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSettingsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF141820)
        )
    }
}

// =========================================================================
// PROMINENT 2-COLUMN DASHBOARD CARD WITH LARGE READABLE FONTS & ANIMATIONS
// =========================================================================
@Composable
fun ProminentDashboardCard(
    title: String,
    badge: String,
    subtitle: String,
    accentColor: Color,
    icon: ImageVector,
    isTwoAction: Boolean,
    action1Icon: ImageVector = Icons.Default.PlayArrow,
    action1Label: String = "PLAY",
    action2Icon: ImageVector = Icons.Default.Settings,
    action2Label: String = "SET",
    onAction1: () -> Unit = {},
    onAction2: () -> Unit = {},
    onCardClick: () -> Unit = {},
    isRunning: Boolean = false,
    centerContent: (@Composable () -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF12151B)),
        modifier = Modifier
            .fillMaxWidth()
            .height(184.dp)
            .border(
                1.5.dp,
                if (isRunning) Color(0xFFFF5252) else accentColor.copy(alpha = 0.65f),
                RoundedCornerShape(20.dp)
            )
            .clickable { onCardClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP ROW: ICON + BADGE
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(accentColor.copy(alpha = 0.18f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .background(accentColor.copy(alpha = 0.22f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = badge,
                        color = accentColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // MIDDLE INFO AND OPTIONAL ANIMATION
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    color = if (isRunning) Color(0xFFFF5252) else Color(0xFFA0AEC0),
                    fontSize = 12.sp,
                    fontWeight = if (isRunning) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (centerContent != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    centerContent()
                }
            }

            // BOTTOM ACTION ROW
            if (isTwoAction) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Button 1 (PLAY / STOP / ADD / CHK)
                    Surface(
                        onClick = onAction1,
                        shape = CircleShape,
                        color = if (isRunning) Color(0xFFFF5252) else accentColor,
                        modifier = Modifier.size(36.dp),
                        shadowElevation = 3.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = action1Icon,
                                contentDescription = action1Label,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Button 2 (SETTING GEAR)
                    Surface(
                        onClick = onAction2,
                        shape = CircleShape,
                        color = Color(0xFFFFB300),
                        modifier = Modifier.size(36.dp),
                        shadowElevation = 3.dp
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = action2Icon,
                                contentDescription = action2Label,
                                tint = Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            } else {
                // Navigation Chevron Button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Open Details",
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Surface(
                        onClick = onCardClick,
                        shape = CircleShape,
                        color = accentColor.copy(alpha = 0.25f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowRight,
                                contentDescription = "Open",
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ================= ANIMATED COMPONENTS FOR CARDS =================

@Composable
fun AnimatedDhyanAura(color: Color, elapsedStr: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "DhyanAura")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Canvas(modifier = Modifier.size(36.dp)) {
            val strokeWidth = 3.dp.toPx()
            val radius = (size.minDimension - strokeWidth) / 2
            drawCircle(
                color = color,
                radius = radius,
                style = Stroke(
                    width = strokeWidth,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), phase)
                )
            )
        }
        Text(
            text = elapsedStr,
            color = Color.White,
            fontSize = 17.sp,
            fontWeight = FontWeight.ExtraBold
        )
    }
}

@Composable
fun AnimatedSoundWaves(color: Color, active: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "SoundWave")
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(500), repeatMode = RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.8f, targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(400), repeatMode = RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(600), repeatMode = RepeatMode.Reverse),
        label = "b3"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(28.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.width(4.dp).fillMaxHeight(if (active) bar1 else 0.4f).background(color, CircleShape))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.width(4.dp).fillMaxHeight(if (active) bar2 else 0.7f).background(color, CircleShape))
        Spacer(modifier = Modifier.width(4.dp))
        Box(modifier = Modifier.width(4.dp).fillMaxHeight(if (active) bar3 else 0.5f).background(color, CircleShape))
    }
}

@Composable
fun KriyaDurationRow(label: String, valueSec: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { if (valueSec > 1) onValueChange(valueSec - 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("-", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("${valueSec}s", color = Color(0xFFFFB300), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalButton(
                onClick = { if (valueSec < 60) onValueChange(valueSec + 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("+", fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun formatDurationSec(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return when {
        h > 0 && m > 0 -> "${h}h ${m}m"
        h > 0 -> "${h}h"
        m > 0 && s > 0 -> "${m}m ${s}s"
        m > 0 -> "${m}m"
        else -> "${s}s"
    }
}

fun formatTimeAmPm(hour24: Int, minute: Int): String {
    val isPm = hour24 >= 12
    val hour12 = when (val h = hour24 % 12) {
        0 -> 12
        else -> h
    }
    return String.format("%02d:%02d %s", hour12, minute, if (isPm) "PM" else "AM")
}

@Composable
fun OdometerTimePicker(
    label: String,
    hour24: Int,
    minute: Int,
    accentColor: Color,
    onTimeChanged: (hour24: Int, minute: Int) -> Unit
) {
    var isPm by remember(hour24) { mutableStateOf(hour24 >= 12) }
    var hour12 by remember(hour24) {
        val h = hour24 % 12
        mutableStateOf(if (h == 0) 12 else h)
    }
    var min by remember(minute) { mutableStateOf(minute) }

    fun emitChange(h12: Int, m: Int, pm: Boolean) {
        val h24 = when {
            pm && h12 < 12 -> h12 + 12
            !pm && h12 == 12 -> 0
            else -> h12
        }
        onTimeChanged(h24, m)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF161922), RoundedCornerShape(12.dp))
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, color = accentColor, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(
                formatTimeAmPm(if (isPm && hour12 < 12) hour12 + 12 else if (!isPm && hour12 == 12) 0 else hour12, min),
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Hour Wheel
            OdometerWheel(
                value = String.format("%02d", hour12),
                onUp = {
                    hour12 = if (hour12 >= 12) 1 else hour12 + 1
                    emitChange(hour12, min, isPm)
                },
                onDown = {
                    hour12 = if (hour12 <= 1) 12 else hour12 - 1
                    emitChange(hour12, min, isPm)
                },
                accentColor = accentColor
            )

            Text(
                " : ",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp)
            )

            // Minute Wheel
            OdometerWheel(
                value = String.format("%02d", min),
                onUp = {
                    min = (min + 1) % 60
                    emitChange(hour12, min, isPm)
                },
                onDown = {
                    min = if (min <= 0) 59 else min - 1
                    emitChange(hour12, min, isPm)
                },
                accentColor = accentColor
            )

            Spacer(modifier = Modifier.width(14.dp))

            // AM / PM Toggle Box
            Row(
                modifier = Modifier
                    .background(Color(0xFF0F1117), RoundedCornerShape(8.dp))
                    .border(1.dp, Color(0xFF2A2E3D), RoundedCornerShape(8.dp))
                    .padding(3.dp)
            ) {
                Surface(
                    onClick = {
                        isPm = false
                        emitChange(hour12, min, false)
                    },
                    shape = RoundedCornerShape(6.dp),
                    color = if (!isPm) accentColor else Color.Transparent
                ) {
                    Text(
                        "AM",
                        color = if (!isPm) Color.Black else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
                Surface(
                    onClick = {
                        isPm = true
                        emitChange(hour12, min, true)
                    },
                    shape = RoundedCornerShape(6.dp),
                    color = if (isPm) accentColor else Color.Transparent
                ) {
                    Text(
                        "PM",
                        color = if (isPm) Color.Black else Color.Gray,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun OdometerWheel(
    value: String,
    onUp: () -> Unit,
    onDown: () -> Unit,
    accentColor: Color
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            onClick = onUp,
            shape = CircleShape,
            color = Color(0xFF232733),
            modifier = Modifier.size(28.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = "▲",
                    color = accentColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .width(46.dp)
                .background(Color(0xFF0F1117), RoundedCornerShape(8.dp))
                .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = value,
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Surface(
            onClick = onDown,
            shape = CircleShape,
            color = Color(0xFF232733),
            modifier = Modifier.size(28.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(
                    text = "▼",
                    color = accentColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
