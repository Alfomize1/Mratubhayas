package com.mratubhayas.app.ui

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.AppPreferences
import com.mratubhayas.app.model.NiyamItem
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(prefs: AppPreferences, onNavigateToDhyan: () -> Unit = {}) {
    val context = LocalContext.current

    // Live clock ticker
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now)
            currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(now)
            delay(1000L)
        }
    }

    // ================= 1. DHYAN STATE =================
    var dhyanRunning by remember { mutableStateOf(false) }
    var dhyanTargetMin by remember { mutableIntStateOf(prefs.getDhyanDurationMin()) }
    var dhyanElapsedSec by remember { mutableIntStateOf(0) }
    var showDhyanSettings by remember { mutableStateOf(false) }
    var dhyanDismissOpt by remember { mutableStateOf(prefs.getDhyanDismissOption()) }
    var dhyanToneUri by remember { mutableStateOf(prefs.getDhyanToneUri()) }
    var dhyanToneIdx by remember { mutableIntStateOf(prefs.getDhyanToneIndex()) }

    // Ringtone Picker Launcher
    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            dhyanToneUri = uri?.toString()
            prefs.setDhyanToneUri(dhyanToneUri)
        }
    }

    // Dhyan Background/Foreground Timer Runner
    LaunchedEffect(dhyanRunning) {
        if (dhyanRunning) {
            dhyanElapsedSec = 0
            val totalSec = dhyanTargetMin * 60
            prefs.scheduleDhyanAlarm(totalSec) // Exact second background alarm
            while (dhyanRunning && dhyanElapsedSec < totalSec) {
                delay(1000L)
                dhyanElapsedSec += 1
            }
            if (dhyanRunning && dhyanElapsedSec >= totalSec) {
                dhyanRunning = false
                // Trigger Lock-Screen Alert with Ant Running circle and Tone
                val intent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", "Dhyan Meditation Completed!")
                    putExtra("TYPE", "DHYAN")
                    putExtra("DISMISS_OPT", dhyanDismissOpt)
                    putExtra("TONE_URI", dhyanToneUri)
                    putExtra("TONE_IDX", dhyanToneIdx)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                context.startActivity(intent)
            }
        } else {
            prefs.cancelDhyanAlarm()
        }
    }

    // ================= 2. KRIYA YOGA STATE =================
    var kriyaRunning by remember { mutableStateOf(false) }
    var kriyaInhaleSec by remember { mutableIntStateOf(prefs.getKriyaInhaleSec()) }
    var kriyaHoldInSec by remember { mutableIntStateOf(prefs.getKriyaHoldInSec()) }
    var kriyaExhaleSec by remember { mutableIntStateOf(prefs.getKriyaExhaleSec()) }
    var kriyaHoldOutSec by remember { mutableIntStateOf(prefs.getKriyaHoldOutSec()) }
    var kriyaPhase by remember { mutableIntStateOf(0) } // 0: Inhale, 1: Hold In, 2: Exhale, 3: Hold Out
    var kriyaSecLeft by remember { mutableIntStateOf(4) }
    var kriyaCycles by remember { mutableIntStateOf(0) }
    var showKriyaSettings by remember { mutableStateOf(false) }

    val phaseNames = listOf("INHALE", "HOLD IN", "EXHALE", "HOLD OUT")

    // Kriya Animated Scale
    val targetScale = when (kriyaPhase) {
        0 -> 1.35f // Inhale expands
        1 -> 1.35f // Hold In
        2 -> 1.0f  // Exhale contracts
        else -> 1.0f // Hold Out
    }
    val animatedKriyaScale by animateFloatAsState(
        targetValue = if (kriyaRunning) targetScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (kriyaRunning) {
                when (kriyaPhase) {
                    0 -> kriyaInhaleSec * 1000
                    1 -> kriyaHoldInSec * 1000
                    2 -> kriyaExhaleSec * 1000
                    else -> kriyaHoldOutSec * 1000
                }
            } else 400,
            easing = LinearEasing
        ),
        label = "KriyaBreathingScale"
    )

    // Kriya Runner
    LaunchedEffect(kriyaRunning) {
        if (kriyaRunning) {
            kriyaPhase = 0
            kriyaCycles = 0
            while (kriyaRunning) {
                val durations = listOf(kriyaInhaleSec, kriyaHoldInSec, kriyaExhaleSec, kriyaHoldOutSec)
                val curDur = durations[kriyaPhase].coerceAtLeast(1)
                NokiaToneEngine.playBeep(440 + (kriyaPhase * 220), 70)
                for (s in curDur downTo 1) {
                    if (!kriyaRunning) break
                    kriyaSecLeft = s
                    delay(1000L)
                }
                if (kriyaPhase == 3) kriyaCycles += 1
                kriyaPhase = (kriyaPhase + 1) % 4
            }
        }
    }

    // ================= 3. NIYAM STATE =================
    var niyamList by remember { mutableStateOf(prefs.getNiyamList()) }
    var showAddNiyamDialog by remember { mutableStateOf(false) }

    // ================= 4. SANSKAR STATE =================
    var sanskarList by remember { mutableStateOf(prefs.getSanskarList()) }

    // ================= 5. SADHANA & TRACKER STATE =================
    var trackerList by remember { mutableStateOf(prefs.getTrackerList()) }
    val sadhanaList by remember { mutableStateOf(prefs.getSadhanaList()) }
    val currentEpochDay = System.currentTimeMillis() / (86400 * 1000L)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E11))
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 40.dp)
    ) {
        // TOP DIGITAL CLOCK HEADER
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = currentDate.uppercase(),
                        color = Color(0xFFFFB300),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = currentTime,
                        color = Color.White,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }

        // ================= TILE 1: DHYAN TIMER =================
        item {
            val totalSec = dhyanTargetMin * 60
            val progress = if (totalSec > 0) dhyanElapsedSec.toFloat() / totalSec.toFloat() else 0f
            val remainingSec = (totalSec - dhyanElapsedSec).coerceAtLeast(0)
            val displayMin = remainingSec / 60
            val displaySec = remainingSec % 60
            val elapsedMin = dhyanElapsedSec / 60
            val elapsedSecRem = dhyanElapsedSec % 60

            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f), RoundedCornerShape(22.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Title Bar with Gear Icon
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFF00E5FF).copy(alpha = 0.15f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "1. DHYAN MEDITATION",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Target: ${dhyanTargetMin}m | Dismiss: $dhyanDismissOpt",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Gear Settings Button
                        IconButton(onClick = { showDhyanSettings = true }) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color(0xFFFFB300)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Counter / Duration Setup
                    if (!dhyanRunning) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilledTonalButton(
                                onClick = {
                                    if (dhyanTargetMin > 5) {
                                        dhyanTargetMin -= 5
                                        prefs.setDhyanDurationMin(dhyanTargetMin)
                                    }
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("- 5m", fontWeight = FontWeight.Bold, color = Color.White)
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Text(
                                text = "${dhyanTargetMin} min",
                                color = Color.White,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            Spacer(modifier = Modifier.width(16.dp))

                            FilledTonalButton(
                                onClick = {
                                    dhyanTargetMin += 5
                                    prefs.setDhyanDurationMin(dhyanTargetMin)
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("+ 5m", fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    } else {
                        // Running state
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = String.format(Locale.getDefault(), "%02d:%02d", displayMin, displaySec),
                                color = Color.White,
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Elapsed: ${String.format(Locale.getDefault(), "%02d:%02d", elapsedMin, elapsedSecRem)} / ${dhyanTargetMin}:00",
                                color = Color(0xFF00E5FF),
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = progress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp),
                                color = Color(0xFF00E5FF),
                                trackColor = Color(0xFF262A34)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Prominent Play/Pause Button
                    Button(
                        onClick = { dhyanRunning = !dhyanRunning },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (dhyanRunning) Color(0xFFFF5252) else Color(0xFF00E5FF)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Icon(
                            imageVector = if (dhyanRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (dhyanRunning) "STOP DHYAN SESSION" else "START ${dhyanTargetMin}M DHYAN",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // ================= TILE 2: KRIYA YOGA (BOX PRANAYAMA) =================
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFFFFB300).copy(alpha = 0.3f), RoundedCornerShape(22.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    // Header Bar with Gear
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFFFB300).copy(alpha = 0.15f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = null,
                                        tint = Color(0xFFFFB300),
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "2. KRIYA YOGA PRANAYAMA",
                                    color = Color(0xFFFFB300),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Box: ${kriyaInhaleSec}s-${kriyaHoldInSec}s-${kriyaExhaleSec}s-${kriyaHoldOutSec}s",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        // Gear Button
                        IconButton(onClick = { showKriyaSettings = true }) {
                            Icon(
                                Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color(0xFF00E5FF)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Animated Breathing Visual Center
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // Outer Pulsing Circle
                        Box(
                            modifier = Modifier
                                .size(130.dp)
                                .scale(animatedKriyaScale)
                                .background(Color(0xFFFFB300).copy(alpha = 0.12f), CircleShape)
                                .border(2.dp, Color(0xFFFFB300).copy(alpha = 0.4f), CircleShape)
                        )

                        // Inner Center Info
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (kriyaRunning) phaseNames[kriyaPhase] else "READY",
                                color = Color(0xFFFFB300),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (kriyaRunning) {
                                Text(
                                    text = "${kriyaSecLeft}s",
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "Cycles: $kriyaCycles",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                            } else {
                                Text(
                                    text = "Tap Start",
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Prominent Play/Pause Button
                    Button(
                        onClick = { kriyaRunning = !kriyaRunning },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (kriyaRunning) Color(0xFFFF5252) else Color(0xFFFFB300)
                        ),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                    ) {
                        Icon(
                            imageVector = if (kriyaRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.Black
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (kriyaRunning) "STOP PRANAYAMA" else "START KRIYA YOGA",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // ================= TILE 3: NIYAM EXACT ALARMS =================
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "3. NIYAM DISCIPLINES",
                                color = Color(0xFF00E5FF),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${niyamList.count { it.active }} Active Exact Alarms",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }

                        Row {
                            OutlinedButton(
                                onClick = {
                                    val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                        putExtra("TITLE", "Test Niyam Alarm")
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                    }
                                    context.startActivity(testIntent)
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text("Test Alert", color = Color(0xFFFFB300), fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            IconButton(onClick = { showAddNiyamDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF00E5FF))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    niyamList.take(3).forEach { item ->
                        val rh = if (item.hour % 12 == 0) 12 else item.hour % 12
                        val amPm = if (item.hour >= 12) "PM" else "AM"
                        val timeStr = String.format(Locale.getDefault(), "%02d:%02d %s", rh, item.minute, amPm)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(timeStr, color = Color(0xFF00E5FF), fontSize = 12.sp)
                            }
                            Switch(
                                checked = item.active,
                                onCheckedChange = { active ->
                                    val updated = niyamList.map {
                                        if (it.id == item.id) it.copy(active = active) else it
                                    }
                                    niyamList = updated.toMutableList()
                                    prefs.saveNiyamList(updated)
                                }
                            )
                        }
                    }
                }
            }
        }

        // ================= TILE 4: SANSKAR MINDFUL CHIMES =================
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "4. SANSKAR PERIODIC CHIMES",
                                color = Color(0xFFFFB300),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Acoustic chimes for mindful presence",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = { NokiaToneEngine.playTone(0, loop = false) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34))
                        ) {
                            Text("Test Chime", color = Color(0xFFFFB300), fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    sanskarList.take(2).forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Every ${item.intervalMin}m | ${item.startHour}:00 - ${item.endHour}:00", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = item.active,
                                onCheckedChange = { active ->
                                    val updated = sanskarList.map {
                                        if (it.id == item.id) it.copy(active = active) else it
                                    }
                                    sanskarList = updated.toMutableList()
                                    prefs.saveSanskarList(updated)
                                }
                            )
                        }
                    }
                }
            }
        }

        // ================= TILE 5: SADHANA & HABIT TRACKER =================
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161922)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "5. SADHANA & HABIT TRACKER",
                        color = Color(0xFF00E5FF),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    trackerList.take(2).forEach { item ->
                        val isMarkedToday = item.lastCheckedEpochDay == currentEpochDay
                        val totalProgress = if (item.targetDays > 0) item.completedDays.toFloat() / item.targetDays.toFloat() else 0f

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Done: ${item.completedDays}d | Goal: ${item.targetDays}d", color = Color.Gray, fontSize = 11.sp)
                            }

                            if (isMarkedToday) {
                                FilledTonalButton(
                                    onClick = {},
                                    enabled = false,
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Done", color = Color(0xFF00E5FF), fontSize = 12.sp)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        val updated = trackerList.map {
                                            if (it.id == item.id) {
                                                it.copy(
                                                    completedDays = it.completedDays + 1,
                                                    lastCheckedEpochDay = currentEpochDay
                                                )
                                            } else it
                                        }
                                        trackerList = updated.toMutableList()
                                        prefs.saveTrackerList(updated)
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                                ) {
                                    Text("Mark Today", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = totalProgress,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp),
                            color = Color(0xFF00E5FF),
                            trackColor = Color(0xFF262A34)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        }
    }

    // ================= DHYAN SETTINGS DIALOG =================
    if (showDhyanSettings) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")
        val nokiaMelodyNames = listOf("Nokia Intro", "SMS Special", "Nostalgia", "William Tell", "Polka")

        AlertDialog(
            onDismissRequest = { showDhyanSettings = false },
            title = {
                Text("Dhyan Settings", color = Color(0xFF00E5FF), fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Auto-Dismiss Duration:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = dhyanDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    dhyanDismissOpt = opt
                                    prefs.setDhyanDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF00E5FF),
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text("Alert Sound Selection:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                    // 8-bit synthetic Nokia tones options
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        nokiaMelodyNames.forEachIndexed { idx, name ->
                            val isSelected = dhyanToneIdx == idx && dhyanToneUri == null
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        dhyanToneIdx = idx
                                        dhyanToneUri = null
                                        prefs.setDhyanToneIndex(idx)
                                        prefs.setDhyanToneUri(null)
                                        NokiaToneEngine.playTone(idx, loop = false)
                                    }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = if (isSelected) Color(0xFF00E5FF) else Color.White, fontSize = 13.sp)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Custom Audio Picker from Phone
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Alert Sound")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            }
                            ringtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (dhyanToneUri != null) "Custom Tone Selected" else "Choose from Phone Storage",
                            color = Color(0xFFFFB300),
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showDhyanSettings = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF))
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // ================= KRIYA YOGA SETTINGS DIALOG =================
    if (showKriyaSettings) {
        AlertDialog(
            onDismissRequest = { showKriyaSettings = false },
            title = {
                Text("Kriya Yoga Breathing (Seconds)", color = Color(0xFFFFB300), fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    KriyaDurationRow("Breath In Time", kriyaInhaleSec) {
                        kriyaInhaleSec = it
                        prefs.setKriyaInhaleSec(it)
                    }
                    KriyaDurationRow("Hold In Time", kriyaHoldInSec) {
                        kriyaHoldInSec = it
                        prefs.setKriyaHoldInSec(it)
                    }
                    KriyaDurationRow("Breath Out Time", kriyaExhaleSec) {
                        kriyaExhaleSec = it
                        prefs.setKriyaExhaleSec(it)
                    }
                    KriyaDurationRow("Hold Out Time", kriyaHoldOutSec) {
                        kriyaHoldOutSec = it
                        prefs.setKriyaHoldOutSec(it)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showKriyaSettings = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300))
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // ================= ADD NIYAM DIALOG =================
    if (showAddNiyamDialog) {
        var nTitle by remember { mutableStateOf("") }
        var nHour by remember { mutableIntStateOf(6) }
        var nMin by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { showAddNiyamDialog = false },
            title = { Text("Add Niyam Alarm", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nTitle,
                        onValueChange = { nTitle = it },
                        label = { Text("Title") },
                        singleLine = true
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Time: ${String.format(Locale.getDefault(), "%02d:%02d", nHour, nMin)}", color = Color.White)
                        Row {
                            Button(onClick = { nHour = (nHour + 1) % 24 }) { Text("+1h") }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(onClick = { nMin = (nMin + 15) % 60 }) { Text("+15m") }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (nTitle.isNotBlank()) {
                        val newItem = NiyamItem(title = nTitle, hour = nHour, minute = nMin, active = true)
                        val updated = niyamList.toMutableList().apply { add(newItem) }
                        niyamList = updated
                        prefs.saveNiyamList(updated)
                        showAddNiyamDialog = false
                    }
                }) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddNiyamDialog = false }) { Text("Cancel") }
            },
            containerColor = Color(0xFF1E222D)
        )
    }
}

@Composable
fun KriyaDurationRow(label: String, valueSec: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { if (valueSec > 1) onValueChange(valueSec - 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("-", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("${valueSec}s", color = Color(0xFFFFB300), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalButton(
                onClick = { if (valueSec < 30) onValueChange(valueSec + 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("+", fontWeight = FontWeight.Bold)
            }
        }
    }
}
