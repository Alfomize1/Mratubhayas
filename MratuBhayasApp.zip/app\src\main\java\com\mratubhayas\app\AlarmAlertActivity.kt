package com.mratubhayas.app

import android.app.KeyguardManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.AppPreferences
import com.mratubhayas.app.model.DailyLogItem
import java.text.SimpleDateFormat
import java.util.*

class AlarmAlertActivity : ComponentActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var autoDismissRunnable: Runnable? = null
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wake screen and display over lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            keyguardManager.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        val title = intent.getStringExtra("TITLE") ?: "Niyam Time!"
        val alertType = intent.getStringExtra("TYPE") ?: "NIYAM"
        val dismissOpt = intent.getStringExtra("DISMISS_OPT") ?: "OFF"
        val toneUriStr = intent.getStringExtra("TONE_URI")
        val toneIdx = intent.getIntExtra("TONE_IDX", 0)
        val prefs = AppPreferences(this)

        // 1. Play alert sound (Custom Phone Tone via MediaPlayer or 8-Bit Nokia Melodies)
        playAlertTone(toneUriStr, toneIdx)

        // 2. Auto-dismiss handler based on user preference: OFF / 10S / 20S / 40S / 1M
        val timeoutMs: Long? = when (dismissOpt) {
            "10S" -> 10000L
            "20S" -> 20000L
            "40S" -> 40000L
            "1M" -> 60000L
            else -> null // "OFF": Plays continuously until user manually stops
        }

        if (timeoutMs != null) {
            autoDismissRunnable = Runnable {
                recordAudit(prefs, title, "MISSED", alertType)
                stopAndFinish()
            }
            handler.postDelayed(autoDismissRunnable!!, timeoutMs)
        }

        setContent {
            AlarmScreen(
                title = title,
                alertType = alertType,
                dismissOpt = dismissOpt,
                onDone = {
                    recordAudit(prefs, title, "DONE", alertType)
                    stopAndFinish()
                },
                onSnooze = {
                    recordAudit(prefs, title, "SNOOZED", alertType)
                    stopAndFinish()
                }
            )
        }
    }

    private fun playAlertTone(toneUriStr: String?, toneIdx: Int) {
        if (!toneUriStr.isNullOrEmpty()) {
            try {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(this@AlarmAlertActivity, Uri.parse(toneUriStr))
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    isLooping = true
                    prepare()
                    start()
                }
                return
            } catch (e: Exception) {
                // Fallback to synthetic tone
            }
        }
        NokiaToneEngine.playTone(toneIdx, loop = true)
    }

    private fun recordAudit(prefs: AppPreferences, title: String, status: String, type: String) {
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        prefs.addLog(
            DailyLogItem(
                title = title,
                timeStr = timeStr,
                status = status,
                type = type
            )
        )
    }

    private fun stopAndFinish() {
        autoDismissRunnable?.let { handler.removeCallbacks(it) }
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {}
        NokiaToneEngine.stop()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAndFinish()
    }
}

// ================= ANTS MARCHING RUNNING CIRCLE ANIMATION =================
@Composable
fun AntRunningCircle(modifier: Modifier = Modifier, color: Color = Color(0xFF00E5FF)) {
    val infiniteTransition = rememberInfiniteTransition(label = "AntRunning")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "antPhase"
    )

    Canvas(modifier = modifier) {
        val strokeWidth = 8.dp.toPx()
        val radius = (size.minDimension - strokeWidth) / 2
        drawCircle(
            color = color,
            radius = radius,
            style = Stroke(
                width = strokeWidth,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), phase)
            )
        )
    }
}

@Composable
fun AlarmScreen(
    title: String,
    alertType: String,
    dismissOpt: String,
    onDone: () -> Unit,
    onSnooze: () -> Unit
) {
    val currentTime = remember {
        SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
    }
    val amPm = remember {
        SimpleDateFormat("a", Locale.getDefault()).format(Date())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E11))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Dynamic Circular Center with "Ant Running" Perimeter
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(170.dp)
            ) {
                // Running Ants Animated Dashed Circle
                AntRunningCircle(
                    modifier = Modifier.fillMaxSize(),
                    color = if (alertType == "DHYAN") Color(0xFF00E5FF) else Color(0xFFFFB300)
                )

                // Glowing Center Surface
                Surface(
                    shape = CircleShape,
                    color = (if (alertType == "DHYAN") Color(0xFF00E5FF) else Color(0xFFFFB300)).copy(alpha = 0.2f),
                    modifier = Modifier.size(120.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Alert",
                            tint = if (alertType == "DHYAN") Color(0xFF00E5FF) else Color(0xFFFFB300),
                            modifier = Modifier.size(54.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            Text(
                text = if (alertType == "DHYAN") "DHYAN COMPLETED" else "NIYAM DISCIPLINE",
                color = if (alertType == "DHYAN") Color(0xFF00E5FF) else Color(0xFFFFB300),
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 3.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = currentTime,
                    color = Color.White,
                    fontSize = 52.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = amPm,
                    color = Color.Gray,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 10.dp)
                )
            }

            if (dismissOpt == "OFF") {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Continuous ringing until dismissed",
                    color = Color(0xFFFF5252),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(42.dp))

            if (alertType == "DHYAN") {
                // Prominent single dismiss button for Dhyan
                Button(
                    onClick = onDone,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        "DISMISS MEDITATION ALERT",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // Snooze Button
                    Button(
                        onClick = onSnooze,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(56.dp)
                            .weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Snooze (5m)", color = Color.White, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Done Button
                    Button(
                        onClick = onDone,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(56.dp)
                            .weight(1f)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Done", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}
