package com.mratubhayas.app.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.R
import com.mratubhayas.app.model.AppPreferences
import java.util.*

class SanskarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("TITLE") ?: "Sanskar Reminder"
        val sanskarId = intent.getLongExtra("SANSKAR_ID", 0L)
        val prefs = AppPreferences(context)

        val sanskar = prefs.getSanskarList().find { it.id == sanskarId }
            ?: prefs.getSanskarList().firstOrNull { it.active }

        if (sanskar != null && sanskar.active) {
            val now = Calendar.getInstance()
            val curMinOfDay = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val startMinOfDay = prefs.getSanskarStartHour() * 60 + prefs.getSanskarStartMinute()
            val endMinOfDay = prefs.getSanskarEndHour() * 60 + prefs.getSanskarEndMinute()

            val inWindow = if (startMinOfDay <= endMinOfDay) {
                curMinOfDay in startMinOfDay..endMinOfDay
            } else {
                curMinOfDay >= startMinOfDay || curMinOfDay <= endMinOfDay
            }

            if (inWindow) {
                // 1. Physically turn on the screen using FULL_WAKE_LOCK & ACQUIRE_CAUSES_WAKEUP
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                @Suppress("DEPRECATION")
                val wakeLock = pm.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                    "MratuBhayas:SanskarWakeLock"
                )
                wakeLock.acquire(30000L)

                val dismissOpt = prefs.getSanskarDismissOption()
                val toneUriStr = prefs.getSanskarToneUri()
                val toneIdx = prefs.getSanskarToneIndex()
                val volume = prefs.getSanskarVolume()
                val reqCode = (Math.abs(sanskar.id.hashCode()) % 40000) + 20000

                // 2. Prepare Full-Screen Lock Screen Alarm Activity
                val fullScreenIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", sanskar.title)
                    putExtra("TYPE", "SANSKAR")
                    putExtra("DISMISS_OPT", dismissOpt)
                    putExtra("TONE_URI", toneUriStr)
                    putExtra("TONE_IDX", toneIdx)
                    putExtra("VOLUME", volume)
                    putExtra("NOTIFICATION_ID", reqCode)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP
                }

                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    reqCode,
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // 3. Post High Priority Notification with Full Screen Intent (SILENT Channel - NO system alarm sound)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channelId = "sanskar_silent_channel_v9"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        notificationManager.deleteNotificationChannel("sanskar_lock_channel_v8")
                    } catch (e: Exception) {}

                    val channel = NotificationChannel(
                        channelId,
                        "Sanskar Fullscreen Alarm",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Full screen lockscreen alert for Sanskar reminders"
                        enableVibration(true)
                        vibrationPattern = longArrayOf(0, 500, 250, 500)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                        setBypassDnd(true)
                        setSound(null, null)
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                val notification = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle(sanskar.title)
                    .setContentText("Mindful Reminder")
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)
                    .setVibrate(longArrayOf(0, 500, 250, 500))
                    .setSound(null)
                    .build()

                notificationManager.notify(reqCode, notification)

                try {
                    context.startActivity(fullScreenIntent)
                } catch (e: Exception) {}
            }

            // 4. Always Reschedule Next Interval
            prefs.scheduleSanskarAlarm(sanskar)
        }
    }
}
