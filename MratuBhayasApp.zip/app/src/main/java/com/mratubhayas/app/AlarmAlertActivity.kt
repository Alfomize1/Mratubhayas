package com.mratubhayas.app

import android.app.KeyguardManager
import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.AppPreferences
import com.mratubhayas.app.model.DailyLogItem
import java.text.SimpleDateFormat
import java.util.*

class AlarmAlertActivity : ComponentActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private var autoDismissRunnable: Runnable? = null
    private var mediaPlayer: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupLockscreenFlags()

        val title = intent.getStringExtra("TITLE") ?: "Mindful Reminder"
        val alertType = intent.getStringExtra("TYPE") ?: "NIYAM"
        val dismissOpt = intent.getStringExtra("DISMISS_OPT") ?: "OFF"
        val toneUriStr = intent.getStringExtra("TONE_URI")
        val toneIdx = intent.getIntExtra("TONE_IDX", 0)
        val volume = intent.getFloatExtra("VOLUME", 0.85f)
        val prefs = AppPreferences(this)

        // 1. Play alert sound (Custom Phone Tone via MediaPlayer or 8-Bit Nokia Melodies)
        playAlertTone(toneUriStr, toneIdx, volume)

        // 2. Auto-dismiss handler based on user preference: OFF / 10S / 20S / 40S / 1M
        val timeoutMs: Long? = when (dismissOpt) {
            "10S" -> 10000L
            "20S" -> 20000L
            "40S" -> 40000L
            "1M" -> 60000L
            else -> null // "OFF": Plays continuously until user manually stops
        }

        if (timeoutMs != null) {
            autoDismissRunnable = Runnable {
                recordAudit(prefs, title, "MISSED", alertType)
                stopAndFinish()
            }
            handler.postDelayed(autoDismissRunnable!!, timeoutMs)
        }

        setContent {
            AlarmScreen(
                title = title,
                alertType = alertType,
                dismissOpt = dismissOpt,
                onDone = {
                    recordAudit(prefs, title, "DONE", alertType)
                    stopAndFinish()
                },
                onSnooze = {
                    recordAudit(prefs, title, "SNOOZED", alertType)
                    stopAndFinish()
                }
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        setupLockscreenFlags()
    }

    override fun onResume() {
        super.onResume()
        setupLockscreenFlags()
    }

    private fun setupLockscreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.requestDismissKeyguard(this, null)
        }
        @Suppress("DEPRECATION")
        window.addFlags(
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
        )
    }

    private fun playAlertTone(toneUriStr: String?, toneIdx: Int, volume: Float) {
        NokiaToneEngine.volume = volume
        if (!toneUriStr.isNullOrEmpty()) {
            try {
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(this@AlarmAlertActivity, Uri.parse(toneUriStr))
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    isLooping = true
                    setVolume(volume, volume)
                    prepare()
                    start()
                }
                return
            } catch (e: Exception) {
                // Fallback to synthetic tone
            }
        }
        NokiaToneEngine.playTone(toneIdx, loop = true)
    }

    private fun recordAudit(prefs: AppPreferences, title: String, status: String, type: String) {
        val timeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        prefs.addLog(
            DailyLogItem(
                title = title,
                timeStr = timeStr,
                status = status,
                type = type
            )
        )
    }

    private fun stopAndFinish() {
        autoDismissRunnable?.let { handler.removeCallbacks(it) }
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {}
        NokiaToneEngine.stop()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAndFinish()
    }
}

// ================= ANTS MARCHING RUNNING SQUARE ANIMATION =================
@Composable
fun AntRunningSquare(
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF00E5FF),
    cornerRadius: Dp = 24.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AntRunningSquare")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "antPhaseSquare"
    )

    Canvas(modifier = modifier) {
        val strokeWidth = 8.dp.toPx()
        val cornerPx = cornerRadius.toPx()
        drawRoundRect(
            color = color,
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(cornerPx, cornerPx),
            style = Stroke(
                width = strokeWidth,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), phase)
            )
        )
    }
}

// ================= ANTS MARCHING RUNNING CIRCLE ANIMATION =================
@Composable
fun AntRunningCircle(modifier: Modifier = Modifier, color: Color = Color(0xFF00E5FF)) {
    val infiniteTransition = rememberInfiniteTransition(label = "AntRunningCircle")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "antPhaseCircle"
    )

    Canvas(modifier = modifier) {
        val strokeWidth = 8.dp.toPx()
        val radius = (size.minDimension - strokeWidth) / 2
        drawCircle(
            color = color,
            radius = radius,
            style = Stroke(
                width = strokeWidth,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 16f), phase)
            )
        )
    }
}

@Composable
fun AlarmScreen(
    title: String,
    alertType: String,
    dismissOpt: String,
    onDone: () -> Unit,
    onSnooze: () -> Unit
) {
    val currentTime = remember {
        SimpleDateFormat("hh:mm", Locale.getDefault()).format(Date())
    }
    val amPm = remember {
        SimpleDateFormat("a", Locale.getDefault()).format(Date())
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0E11))
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 32.dp)
        ) {
            // ================= 1. TOP SECTION =================
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (alertType == "SANSKAR") {
                    // SANSKAR: NOTE TITLE AT THE VERY TOP (Large, Prominent, Cyan, No Time Display)
                    Text(
                        text = "MINDFUL SANSKAR",
                        color = Color(0xFF00E5FF).copy(alpha = 0.8f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = title,
                        color = Color(0xFF00E5FF),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        lineHeight = 38.sp,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                } else {
                    Text(
                        text = if (alertType == "DHYAN") "DHYAN COMPLETED" else "NIYAM DISCIPLINE",
                        color = if (alertType == "DHYAN") Color(0xFF10B981) else Color(0xFFFFB300),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 3.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // ================= 2. CENTER VISUAL SECTION =================
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (alertType == "SANSKAR") {
                    // SANSKAR: RUNNING ANT BORDER SQUARE / ROUNDED RECTANGLE
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(190.dp)
                    ) {
                        AntRunningSquare(
                            modifier = Modifier.fillMaxSize(),
                            color = Color(0xFF00E5FF),
                            cornerRadius = 28.dp
                        )
                        Surface(
                            shape = RoundedCornerShape(22.dp),
                            color = Color(0xFF00E5FF).copy(alpha = 0.16f),
                            modifier = Modifier.size(146.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Alert",
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(54.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "AWARENESS",
                                        color = Color(0xFF00E5FF),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 2.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = if (dismissOpt == "OFF") "Continuous ringing until dismissed" else "Auto-dismiss in $dismissOpt",
                        color = if (dismissOpt == "OFF") Color(0xFFFF5252) else Color.Gray,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                } else {
                    // DHYAN & OTHER ALARMS: CIRCULAR AURA + TIME DISPLAY
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(170.dp)
                    ) {
                        AntRunningCircle(
                            modifier = Modifier.fillMaxSize(),
                            color = if (alertType == "DHYAN") Color(0xFF10B981) else Color(0xFFFFB300)
                        )
                        Surface(
                            shape = CircleShape,
                            color = (if (alertType == "DHYAN") Color(0xFF10B981) else Color(0xFFFFB300)).copy(alpha = 0.2f),
                            modifier = Modifier.size(120.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = if (alertType == "DHYAN") Icons.Default.PlayArrow else Icons.Default.Notifications,
                                    contentDescription = "Alert",
                                    tint = if (alertType == "DHYAN") Color(0xFF10B981) else Color(0xFFFFB300),
                                    modifier = Modifier.size(54.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = currentTime,
                            color = Color.White,
                            fontSize = 48.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = amPm,
                            color = Color.Gray,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }

                    if (dismissOpt == "OFF") {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Continuous ringing until dismissed",
                            color = Color(0xFFFF5252),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // ================= 3. BOTTOM BUTTONS SECTION =================
            Column(modifier = Modifier.fillMaxWidth()) {
                if (alertType == "DHYAN") {
                    Button(
                        onClick = onDone,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(58.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "DISMISS MEDITATION ALERT",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Snooze Button
                        Button(
                            onClick = onSnooze,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Snooze (5m)", color = Color.White, fontSize = 15.sp)
                        }

                        // Done Button
                        Button(
                            onClick = onDone,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (alertType == "SANSKAR") Color(0xFF00E5FF) else Color(0xFF10B981)
                            ),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .weight(1f)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Done", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }
    }
}
