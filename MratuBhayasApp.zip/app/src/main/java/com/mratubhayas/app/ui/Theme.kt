package com.mratubhayas.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFF10B981),     // Emerald Green
    secondary = Color(0xFFFFB300),   // Golden Yellow
    background = Color(0xFF000000),  // Pure AMOLED Black
    surface = Color(0xFF121418),     // Deep Charcoal
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun MratuBhayasTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
