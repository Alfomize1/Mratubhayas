package com.mratubhayas.app.model

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.mratubhayas.app.receiver.NiyamAlarmReceiver
import com.mratubhayas.app.receiver.SanskarAlarmReceiver
import java.util.*

class AppPreferences(private val context: Context) {
    private val prefs = context.getSharedPreferences("mratu_bhayas_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    // --- NIYAM LIST ---
    fun getNiyamList(): MutableList<NiyamItem> {
        val json = prefs.getString("niyam_list", null) ?: return mutableListOf(
            NiyamItem(title = "Morning Sadhana", hour = 6, minute = 0, active = true),
            NiyamItem(title = "Evening Meditation", hour = 18, minute = 30, active = true)
        )
        val type = object : TypeToken<MutableList<NiyamItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveNiyamList(list: List<NiyamItem>) {
        prefs.edit().putString("niyam_list", gson.toJson(list)).apply()
        rescheduleAllAlarms()
    }

    // --- SANSKAR LIST ---
    fun getSanskarList(): MutableList<SanskarItem> {
        val json = prefs.getString("sanskar_list", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<SanskarItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveSanskarList(list: List<SanskarItem>) {
        prefs.edit().putString("sanskar_list", gson.toJson(list)).apply()
        rescheduleAllAlarms()
    }

    fun getSanskarDismissOption(): String = prefs.getString("sanskar_dismiss_opt", "10S") ?: "10S"
    fun setSanskarDismissOption(opt: String) = prefs.edit().putString("sanskar_dismiss_opt", opt).apply()

    fun getSanskarStartHour(): Int = prefs.getInt("sanskar_start_hour", 5)
    fun setSanskarStartHour(hour: Int) = prefs.edit().putInt("sanskar_start_hour", hour).apply()

    fun getSanskarStartMinute(): Int = prefs.getInt("sanskar_start_min", 0)
    fun setSanskarStartMinute(minute: Int) = prefs.edit().putInt("sanskar_start_min", minute).apply()

    fun getSanskarEndHour(): Int = prefs.getInt("sanskar_end_hour", 21)
    fun setSanskarEndHour(hour: Int) = prefs.edit().putInt("sanskar_end_hour", hour).apply()

    fun getSanskarEndMinute(): Int = prefs.getInt("sanskar_end_min", 0)
    fun setSanskarEndMinute(minute: Int) = prefs.edit().putInt("sanskar_end_min", minute).apply()

    fun getSanskarVolume(): Float = prefs.getFloat("sanskar_volume", 0.85f)
    fun setSanskarVolume(vol: Float) = prefs.edit().putFloat("sanskar_volume", vol).apply()

    fun getSanskarToneUri(): String? = prefs.getString("sanskar_tone_uri", null)
    fun setSanskarToneUri(uri: String?) = prefs.edit().putString("sanskar_tone_uri", uri).apply()

    fun getSanskarToneIndex(): Int = prefs.getInt("sanskar_tone_idx", 0)
    fun setSanskarToneIndex(idx: Int) = prefs.edit().putInt("sanskar_tone_idx", idx).apply()


    // --- SADHANA LIST ---
    fun getSadhanaList(): MutableList<SadhanaItem> {
        val json = prefs.getString("sadhana_list", null) ?: return mutableListOf(
            SadhanaItem(title = "Mratu Dhyan Anushthan", targetDays = 21, active = true)
        )
        val type = object : TypeToken<MutableList<SadhanaItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveSadhanaList(list: List<SadhanaItem>) {
        prefs.edit().putString("sadhana_list", gson.toJson(list)).apply()
    }

    // --- TRACKER LIST ---
    fun getTrackerList(): MutableList<TrackerItem> {
        val json = prefs.getString("tracker_list", null) ?: return mutableListOf(
            TrackerItem(title = "Daily Naam Japa", targetDays = 40, completedDays = 5, missedDays = 1)
        )
        val type = object : TypeToken<MutableList<TrackerItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveTrackerList(list: List<TrackerItem>) {
        prefs.edit().putString("tracker_list", gson.toJson(list)).apply()
    }

    // --- PLANNER EVENTS ---
    fun getPlannerEvents(): MutableList<PlannerEvent> {
        val json = prefs.getString("planner_list", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<PlannerEvent>>() {}.type
        return gson.fromJson(json, type)
    }

    fun savePlannerEvents(list: List<PlannerEvent>) {
        prefs.edit().putString("planner_list", gson.toJson(list)).apply()
    }

    // --- NOTES ---
    fun getNotes(): MutableList<NoteItem> {
        val json = prefs.getString("notes_list", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<NoteItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun saveNotes(list: List<NoteItem>) {
        prefs.edit().putString("notes_list", gson.toJson(list)).apply()
    }

    // --- LOGS ---
    fun getLogs(): MutableList<DailyLogItem> {
        val json = prefs.getString("daily_logs", null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<DailyLogItem>>() {}.type
        return gson.fromJson(json, type)
    }

    fun addLog(log: DailyLogItem) {
        val logs = getLogs()
        logs.add(0, log)
        if (logs.size > 100) logs.removeAt(logs.size - 1)
        prefs.edit().putString("daily_logs", gson.toJson(logs)).apply()
    }

    // --- DHYAN TIMER SETTINGS (10s to 12h free flow) ---
    fun getDhyanDurationSec(): Int = prefs.getInt("dhyan_dur_sec", 45 * 60).coerceIn(10, 12 * 3600)
    fun setDhyanDurationSec(sec: Int) = prefs.edit().putInt("dhyan_dur_sec", sec.coerceIn(10, 12 * 3600)).apply()

    fun getDhyanDurationMin(): Int = getDhyanDurationSec() / 60
    fun setDhyanDurationMin(min: Int) = setDhyanDurationSec(min * 60)

    fun getDhyanDismissOption(): String = prefs.getString("dhyan_dismiss_opt", "OFF") ?: "OFF"
    fun setDhyanDismissOption(opt: String) = prefs.edit().putString("dhyan_dismiss_opt", opt).apply()

    fun getDhyanToneUri(): String? = prefs.getString("dhyan_tone_uri", null)
    fun setDhyanToneUri(uri: String?) = prefs.edit().putString("dhyan_tone_uri", uri).apply()

    fun getDhyanToneIndex(): Int = prefs.getInt("dhyan_tone_idx", 0)
    fun setDhyanToneIndex(idx: Int) = prefs.edit().putInt("dhyan_tone_idx", idx).apply()

    fun scheduleDhyanAlarm(durationSec: Int) {
        val triggerAt = System.currentTimeMillis() + (durationSec * 1000L)
        val intent = Intent(context, NiyamAlarmReceiver::class.java).apply {
            putExtra("TITLE", "Dhyan Meditation Completed!")
            putExtra("TYPE", "DHYAN")
            putExtra("DISMISS_OPT", getDhyanDismissOption())
            putExtra("TONE_URI", getDhyanToneUri())
            putExtra("TONE_IDX", getDhyanToneIndex())
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            99999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAt, pendingIntent)
        alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
    }

    fun cancelDhyanAlarm() {
        val intent = Intent(context, NiyamAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            99999,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    // --- KRIYA YOGA BREATHING SETTINGS ---
    fun getKriyaInhaleSec(): Int = prefs.getInt("kriya_inhale_sec", 4)
    fun setKriyaInhaleSec(sec: Int) = prefs.edit().putInt("kriya_inhale_sec", sec).apply()

    fun getKriyaHoldInSec(): Int = prefs.getInt("kriya_hold_in_sec", 4)
    fun setKriyaHoldInSec(sec: Int) = prefs.edit().putInt("kriya_hold_in_sec", sec).apply()

    fun getKriyaExhaleSec(): Int = prefs.getInt("kriya_exhale_sec", 4)
    fun setKriyaExhaleSec(sec: Int) = prefs.edit().putInt("kriya_exhale_sec", sec).apply()

    fun getKriyaHoldOutSec(): Int = prefs.getInt("kriya_hold_out_sec", 4)
    fun setKriyaHoldOutSec(sec: Int) = prefs.edit().putInt("kriya_hold_out_sec", sec).apply()

    // ================= EXACT-SECOND BACKGROUND ALARM SCHEDULING =================
    fun rescheduleAllAlarms() {
        val niyamList = getNiyamList()
        for (item in niyamList) {
            if (item.active) scheduleExactNiyamAlarm(item)
            else cancelNiyamAlarm(item)
        }

        val sanskarList = getSanskarList()
        for (item in sanskarList) {
            if (item.active) scheduleSanskarAlarm(item)
            else cancelSanskarAlarm(item)
        }
    }

    fun scheduleExactNiyamAlarm(item: NiyamItem) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, item.hour)
            set(Calendar.MINUTE, item.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1) // Schedule for tomorrow if time has passed
            }
        }

        val intent = Intent(context, NiyamAlarmReceiver::class.java).apply {
            putExtra("NIYAM_ID", item.id)
            putExtra("TITLE", item.title)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            item.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // setAlarmClock is Android's highest priority alarm API.
        // It bypasses Doze Mode and deep sleep, firing at the EXACT millisecond!
        val alarmClockInfo = AlarmManager.AlarmClockInfo(calendar.timeInMillis, pendingIntent)
        alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
    }

    fun cancelNiyamAlarm(item: NiyamItem) {
        val intent = Intent(context, NiyamAlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            item.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }

    fun scheduleSanskarAlarm(item: SanskarItem) {
        val triggerAt = System.currentTimeMillis() + (item.intervalMin * 60 * 1000L)
        val intent = Intent(context, SanskarAlarmReceiver::class.java).apply {
            putExtra("SANSKAR_ID", item.id)
            putExtra("TITLE", item.title)
        }
        val reqCode = (Math.abs(item.id.hashCode()) % 40000) + 20000
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerAt, pendingIntent)
        alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
    }

    fun cancelSanskarAlarm(item: SanskarItem) {
        val intent = Intent(context, SanskarAlarmReceiver::class.java)
        val reqCode = (Math.abs(item.id.hashCode()) % 40000) + 20000
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            reqCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
