package com.mratubhayas.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.*
import com.mratubhayas.app.service.DhyanNotificationHelper
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(prefs: AppPreferences) {
    val context = LocalContext.current

    // Live Clock Ticker
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now)
            currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(now)
            delay(1000L)
        }
    }

    // ================= 1. DHYAN STATE =================
    var dhyanRunning by remember { mutableStateOf(false) }
    var dhyanTargetSec by remember { mutableIntStateOf(prefs.getDhyanDurationSec()) }
    var dhyanElapsedSec by remember { mutableIntStateOf(0) }
    var showDhyanDialog by remember { mutableStateOf(false) }
    var showDhyanTimeFeedDialog by remember { mutableStateOf(false) }
    var dhyanDismissOpt by remember { mutableStateOf(prefs.getDhyanDismissOption()) }
    var dhyanToneUri by remember { mutableStateOf(prefs.getDhyanToneUri()) }
    var dhyanToneIdx by remember { mutableIntStateOf(prefs.getDhyanToneIndex()) }

    // Ringtone Picker Launcher
    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            dhyanToneUri = uri?.toString()
            prefs.setDhyanToneUri(dhyanToneUri)
        }
    }

    // Dhyan Runner: Foreground Notification + Status Bar Icon + Lock Screen Display
    LaunchedEffect(dhyanRunning) {
        if (dhyanRunning) {
            dhyanElapsedSec = 0
            prefs.scheduleDhyanAlarm(dhyanTargetSec) // Exact background alarm clock info
            DhyanNotificationHelper.updateDhyanNotification(context, dhyanElapsedSec, dhyanTargetSec)

            while (dhyanRunning && dhyanElapsedSec < dhyanTargetSec) {
                delay(1000L)
                dhyanElapsedSec += 1
                // Update live timer on status bar & lock screen
                DhyanNotificationHelper.updateDhyanNotification(context, dhyanElapsedSec, dhyanTargetSec)
            }

            if (dhyanRunning && dhyanElapsedSec >= dhyanTargetSec) {
                dhyanRunning = false
                DhyanNotificationHelper.cancelDhyanNotification(context)

                // Launch Lock-Screen Alert Activity with Ant Running Circle and Alert Tone
                val intent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", "Dhyan Meditation Completed!")
                    putExtra("TYPE", "DHYAN")
                    putExtra("DISMISS_OPT", dhyanDismissOpt)
                    putExtra("TONE_URI", dhyanToneUri)
                    putExtra("TONE_IDX", dhyanToneIdx)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                context.startActivity(intent)
            }
        } else {
            prefs.cancelDhyanAlarm()
            DhyanNotificationHelper.cancelDhyanNotification(context)
        }
    }

    // ================= 2. KRIYA YOGA STATE =================
    var kriyaRunning by remember { mutableStateOf(false) }
    var kriyaInhaleSec by remember { mutableIntStateOf(prefs.getKriyaInhaleSec()) }
    var kriyaHoldInSec by remember { mutableIntStateOf(prefs.getKriyaHoldInSec()) }
    var kriyaExhaleSec by remember { mutableIntStateOf(prefs.getKriyaExhaleSec()) }
    var kriyaHoldOutSec by remember { mutableIntStateOf(prefs.getKriyaHoldOutSec()) }
    var kriyaPhase by remember { mutableIntStateOf(0) } // 0: Inhale, 1: Hold In, 2: Exhale, 3: Hold Out
    var kriyaSecLeft by remember { mutableIntStateOf(4) }
    var kriyaCycles by remember { mutableIntStateOf(0) }
    var showKriyaDialog by remember { mutableStateOf(false) }

    val phaseNames = listOf("INHALE", "HOLD IN", "EXHALE", "HOLD OUT")

    val targetScale = when (kriyaPhase) {
        0 -> 1.4f
        1 -> 1.4f
        2 -> 1.0f
        else -> 1.0f
    }
    val animatedKriyaScale by animateFloatAsState(
        targetValue = if (kriyaRunning) targetScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (kriyaRunning) {
                when (kriyaPhase) {
                    0 -> kriyaInhaleSec * 1000
                    1 -> kriyaHoldInSec * 1000
                    2 -> kriyaExhaleSec * 1000
                    else -> kriyaHoldOutSec * 1000
                }
            } else 350,
            easing = LinearEasing
        ),
        label = "KriyaBreathingScale"
    )

    LaunchedEffect(kriyaRunning) {
        if (kriyaRunning) {
            kriyaPhase = 0
            kriyaCycles = 0
            while (kriyaRunning) {
                val durations = listOf(kriyaInhaleSec, kriyaHoldInSec, kriyaExhaleSec, kriyaHoldOutSec)
                val curDur = durations[kriyaPhase].coerceAtLeast(1)
                NokiaToneEngine.playBeep(440 + (kriyaPhase * 220), 80)
                for (s in curDur downTo 1) {
                    if (!kriyaRunning) break
                    kriyaSecLeft = s
                    delay(1000L)
                }
                if (kriyaPhase == 3) kriyaCycles += 1
                kriyaPhase = (kriyaPhase + 1) % 4
            }
        }
    }

    // ================= 3. SANSKAR STATE =================
    var sanskarList by remember { mutableStateOf(prefs.getSanskarList()) }
    var showSanskarDialog by remember { mutableStateOf(false) }
    var showAddSanskarDialog by remember { mutableStateOf(false) }
    var showSanskarSettingsDialog by remember { mutableStateOf(false) }
    var sanskarDismissOpt by remember { mutableStateOf(prefs.getSanskarDismissOption()) }
    var sanskarStartHour by remember { mutableIntStateOf(prefs.getSanskarStartHour()) }
    var sanskarEndHour by remember { mutableIntStateOf(prefs.getSanskarEndHour()) }

    // ================= OTHER SHEETS STATE =================
    var showSankalpSheet by remember { mutableStateOf(false) }
    var showAlarmsSheet by remember { mutableStateOf(false) }
    var showNotesSheet by remember { mutableStateOf(false) }
    var showLogsSheet by remember { mutableStateOf(false) }
    var showPlannerSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    var niyamList by remember { mutableStateOf(prefs.getNiyamList()) }
    var trackerList by remember { mutableStateOf(prefs.getTrackerList()) }
    val currentEpochDay = System.currentTimeMillis() / (86400 * 1000L)

    // THEMED COLORS: GREEN (#10B981) + GOLDEN YELLOW (#FFB300) + PURE BLACK (#000000)
    val colorGreen = Color(0xFF10B981)
    val colorYellow = Color(0xFFFFB300)
    val colorBg = Color(0xFF000000)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colorBg)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // TOP HEADER: BRANDING & LIVE CLOCK
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MRATUBHAYAS",
                    color = colorYellow,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.sp
                )
                Box(
                    modifier = Modifier
                        .background(colorGreen.copy(alpha = 0.18f), RoundedCornerShape(12.dp))
                        .border(1.dp, colorGreen.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (dhyanRunning) "DHYAN RUNNING" else "VEDIC SYSTEM ACTIVE",
                        color = colorGreen,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = currentDate.uppercase(),
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = currentTime,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // ================= 3x3 TILES GRID =================
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // ROW 1, COL 1: DHYAN
            item {
                GridDashboardTile(
                    title = "Dhyan",
                    badge = "ध्यान",
                    subtitle = if (!dhyanRunning) formatDurationSec(dhyanTargetSec) else DhyanNotificationHelper.formatSeconds(dhyanElapsedSec),
                    accentColor = colorGreen,
                    icon = Icons.Default.PlayArrow,
                    isTwoAction = true,
                    action1Icon = if (dhyanRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (dhyanRunning) "STOP" else "PLAY",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SET",
                    onAction1 = { dhyanRunning = !dhyanRunning },
                    onAction2 = { showDhyanDialog = true },
                    onTileClick = { showDhyanDialog = true },
                    isRunning = dhyanRunning
                )
            }

            // ROW 1, COL 2: KRIYA YOG
            item {
                GridDashboardTile(
                    title = "Kriya Yog",
                    badge = "योग",
                    subtitle = if (!kriyaRunning) "${kriyaInhaleSec}s-${kriyaHoldInSec}s-${kriyaExhaleSec}s-${kriyaHoldOutSec}s" else "${phaseNames[kriyaPhase]} ${kriyaSecLeft}s",
                    accentColor = colorYellow,
                    icon = Icons.Default.Refresh,
                    isTwoAction = true,
                    action1Icon = if (kriyaRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (kriyaRunning) "STOP" else "PLAY",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SET",
                    onAction1 = { kriyaRunning = !kriyaRunning },
                    onAction2 = { showKriyaDialog = true },
                    onTileClick = { showKriyaDialog = true },
                    isRunning = kriyaRunning
                )
            }

            // ROW 1, COL 3: SANSKAR (WITH "+" ADD BUTTON AS REQUESTED)
            item {
                GridDashboardTile(
                    title = "Sanskar",
                    badge = "संस्कार",
                    subtitle = "${sanskarList.count { it.active }} Chimes",
                    accentColor = colorGreen,
                    icon = Icons.Default.Notifications,
                    isTwoAction = true,
                    action1Icon = Icons.Default.Add, // Bell replaced with "+" Add button
                    action1Label = "ADD",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SET",
                    onAction1 = { showAddSanskarDialog = true },
                    onAction2 = { showSanskarSettingsDialog = true },
                    onTileClick = { showSanskarDialog = true }
                )
            }

            // ROW 2, COL 1: SANKALP
            item {
                GridDashboardTile(
                    title = "Sankalp",
                    badge = "संकल्प",
                    subtitle = "Vows & Goals",
                    accentColor = colorYellow,
                    icon = Icons.Default.Check,
                    isTwoAction = true,
                    action1Icon = Icons.Default.Check,
                    action1Label = "CHK",
                    action2Icon = Icons.Default.Settings,
                    action2Label = "SET",
                    onAction1 = {
                        val updated = trackerList.map {
                            if (it.lastCheckedEpochDay != currentEpochDay) {
                                it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                            } else it
                        }
                        trackerList = updated.toMutableList()
                        prefs.saveTrackerList(updated)
                    },
                    onAction2 = { showSankalpSheet = true },
                    onTileClick = { showSankalpSheet = true }
                )
            }

            // ROW 2, COL 2: ALARM
            item {
                GridDashboardTile(
                    title = "Alarm",
                    badge = "अलार्म",
                    subtitle = "${niyamList.count { it.active }} Active",
                    accentColor = colorGreen,
                    icon = Icons.Default.Notifications,
                    isTwoAction = false,
                    onTileClick = { showAlarmsSheet = true }
                )
            }

            // ROW 2, COL 3: NOTES
            item {
                GridDashboardTile(
                    title = "Notes",
                    badge = "नोट्स",
                    subtitle = "${prefs.getNotes().size} Saved",
                    accentColor = colorYellow,
                    icon = Icons.Default.Edit,
                    isTwoAction = false,
                    onTileClick = { showNotesSheet = true }
                )
            }

            // ROW 3, COL 1: LOGS
            item {
                GridDashboardTile(
                    title = "Logs",
                    badge = "लॉग्स",
                    subtitle = "${prefs.getLogs().size} Entries",
                    accentColor = colorGreen,
                    icon = Icons.Default.Star,
                    isTwoAction = false,
                    onTileClick = { showLogsSheet = true }
                )
            }

            // ROW 3, COL 2: PLANNER
            item {
                GridDashboardTile(
                    title = "Planner",
                    badge = "प्लानर",
                    subtitle = "Routines",
                    accentColor = colorYellow,
                    icon = Icons.Default.DateRange,
                    isTwoAction = false,
                    onTileClick = { showPlannerSheet = true }
                )
            }

            // ROW 3, COL 3: SETTING
            item {
                GridDashboardTile(
                    title = "Setting",
                    badge = "सेटिंग",
                    subtitle = "System",
                    accentColor = colorGreen,
                    icon = Icons.Default.Settings,
                    isTwoAction = false,
                    onTileClick = { showSettingsSheet = true }
                )
            }
        }
    }

    // =========================================================================
    // MODAL DIALOGS
    // =========================================================================

    // 1. DHYAN FULL CONTROLS DIALOG (10 SEC TO 12 HOURS FREE FLOW + CLICK TO FEED)
    if (showDhyanDialog) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")
        val nokiaMelodyNames = listOf("Nokia Intro", "SMS Special", "Nostalgia", "William Tell", "Polka")

        AlertDialog(
            onDismissRequest = { showDhyanDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Dhyan Meditation", color = colorGreen, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    IconButton(onClick = { showDhyanDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Target Duration (Click time below to type):",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )

                    // Big Clickable Center Time Display (Click to direct feed!)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF121418), RoundedCornerShape(16.dp))
                            .border(1.5.dp, colorGreen, RoundedCornerShape(16.dp))
                            .clickable { showDhyanTimeFeedDialog = true }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = DhyanNotificationHelper.formatSeconds(dhyanTargetSec),
                                color = colorGreen,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 2.sp
                            )
                            Text(
                                text = "👆 Tap here to type exact value (10s - 12h)",
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Stepper row for quick adjustments
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec - 60).coerceAtLeast(10)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("-1m", fontSize = 11.sp)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec - 300).coerceAtLeast(10)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("-5m", fontSize = 11.sp)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec + 300).coerceAtMost(12 * 3600)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("+5m", fontSize = 11.sp)
                        }

                        FilledTonalButton(
                            onClick = {
                                val newSec = (dhyanTargetSec + 1800).coerceAtMost(12 * 3600)
                                dhyanTargetSec = newSec
                                prefs.setDhyanDurationSec(newSec)
                            },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("+30m", fontSize = 11.sp)
                        }
                    }

                    // Auto-Dismiss Duration (OFF, 10s, 20s, 40s, 1m)
                    Text("Auto-Dismiss Alert:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = dhyanDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    dhyanDismissOpt = opt
                                    prefs.setDhyanDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = colorGreen,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                    Text(
                        text = if (dhyanDismissOpt == "OFF") "Alert rings continuously until user manually stops" else "Auto shuts off after $dhyanDismissOpt",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )

                    // Alert Sound Selection
                    Text("Alert Sound Selection:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        nokiaMelodyNames.forEachIndexed { idx, name ->
                            val isSelected = dhyanToneIdx == idx && dhyanToneUri == null
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        dhyanToneIdx = idx
                                        dhyanToneUri = null
                                        prefs.setDhyanToneIndex(idx)
                                        prefs.setDhyanToneUri(null)
                                        NokiaToneEngine.playTone(idx, loop = false)
                                    }
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = if (isSelected) colorGreen else Color.White, fontSize = 12.sp)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = colorGreen, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Phone Storage Audio Picker
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Alert Sound")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            }
                            ringtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = if (dhyanToneUri != null) "Custom Audio Selected" else "Choose from Phone Storage",
                            color = colorYellow,
                            fontSize = 11.sp
                        )
                    }

                    // Test Alert Button
                    Button(
                        onClick = {
                            val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                putExtra("TITLE", "Test Dhyan Meditation Completed!")
                                putExtra("TYPE", "DHYAN")
                                putExtra("DISMISS_OPT", dhyanDismissOpt)
                                putExtra("TONE_URI", dhyanToneUri)
                                putExtra("TONE_IDX", dhyanToneIdx)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(testIntent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E222A)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = colorYellow, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Lock-Screen Alert Now", color = colorYellow, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        dhyanRunning = !dhyanRunning
                        showDhyanDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (dhyanRunning) Color(0xFFFF5252) else colorGreen
                    )
                ) {
                    Text(if (dhyanRunning) "Stop Session" else "Start Dhyan", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF121418)
        )
    }

    // 1B. DHYAN TIME DIRECT FEED DIALOG (10 SEC TO 12 HOURS)
    if (showDhyanTimeFeedDialog) {
        var inputHours by remember { mutableIntStateOf(dhyanTargetSec / 3600) }
        var inputMins by remember { mutableIntStateOf((dhyanTargetSec % 3600) / 60) }
        var inputSecs by remember { mutableIntStateOf(dhyanTargetSec % 60) }

        AlertDialog(
            onDismissRequest = { showDhyanTimeFeedDialog = false },
            title = {
                Text("Feed Meditation Time", color = colorGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Set any duration from 10 Seconds up to 12 Hours:", color = Color.Gray, fontSize = 11.sp)

                    // Hours Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Hours (0 - 12):", color = Color.White, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputHours > 0) inputHours-- }, shape = RoundedCornerShape(8.dp)) { Text("-") }
                            Text("  $inputHours h  ", color = colorYellow, fontWeight = FontWeight.Bold)
                            Button(onClick = { if (inputHours < 12) inputHours++ }, shape = RoundedCornerShape(8.dp)) { Text("+") }
                        }
                    }

                    // Minutes Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Minutes (0 - 59):", color = Color.White, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputMins > 0) inputMins-- }, shape = RoundedCornerShape(8.dp)) { Text("-") }
                            Text("  $inputMins m  ", color = colorYellow, fontWeight = FontWeight.Bold)
                            Button(onClick = { if (inputMins < 59) inputMins++ }, shape = RoundedCornerShape(8.dp)) { Text("+") }
                        }
                    }

                    // Seconds Stepper
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Seconds (0 - 59):", color = Color.White, fontSize = 13.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(onClick = { if (inputSecs >= 5) inputSecs -= 5 else inputSecs = 0 }, shape = RoundedCornerShape(8.dp)) { Text("-5") }
                            Text("  $inputSecs s  ", color = colorYellow, fontWeight = FontWeight.Bold)
                            Button(onClick = { if (inputSecs <= 54) inputSecs += 5 else inputSecs = 59 }, shape = RoundedCornerShape(8.dp)) { Text("+5") }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val totalSec = (inputHours * 3600 + inputMins * 60 + inputSecs).coerceIn(10, 12 * 3600)
                        dhyanTargetSec = totalSec
                        prefs.setDhyanDurationSec(totalSec)
                        showDhyanTimeFeedDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colorGreen)
                ) {
                    Text("Apply Time", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDhyanTimeFeedDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 2. KRIYA YOGA BREATHING DIALOG
    if (showKriyaDialog) {
        AlertDialog(
            onDismissRequest = { showKriyaDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Kriya Yog Pranayama", color = colorYellow, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { showKriyaDialog = false }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Visual pulsing aura
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .scale(animatedKriyaScale)
                                .background(colorYellow.copy(alpha = 0.15f), CircleShape)
                                .border(2.dp, colorYellow, CircleShape)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (kriyaRunning) phaseNames[kriyaPhase] else "READY",
                                color = colorYellow,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (kriyaRunning) {
                                Text(
                                    text = "${kriyaSecLeft}s",
                                    color = Color.White,
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text("Rounds: $kriyaCycles", color = Color.Gray, fontSize = 10.sp)
                            }
                        }
                    }

                    Text("Breath Phase Timing (Seconds):", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)

                    KriyaDurationRow("Breath In Time", kriyaInhaleSec) {
                        kriyaInhaleSec = it
                        prefs.setKriyaInhaleSec(it)
                    }
                    KriyaDurationRow("Hold In Time", kriyaHoldInSec) {
                        kriyaHoldInSec = it
                        prefs.setKriyaHoldInSec(it)
                    }
                    KriyaDurationRow("Breath Out Time", kriyaExhaleSec) {
                        kriyaExhaleSec = it
                        prefs.setKriyaExhaleSec(it)
                    }
                    KriyaDurationRow("Hold Out Time", kriyaHoldOutSec) {
                        kriyaHoldOutSec = it
                        prefs.setKriyaHoldOutSec(it)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        kriyaRunning = !kriyaRunning
                        showKriyaDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (kriyaRunning) Color(0xFFFF5252) else colorYellow
                    )
                ) {
                    Text(if (kriyaRunning) "Stop Kriya" else "Start Kriya", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF121418)
        )
    }

    // 3. SANSKAR CHIMES MANAGEMENT DIALOG (MULTIPLE SANSKARS LIST)
    if (showSanskarDialog) {
        AlertDialog(
            onDismissRequest = { showSanskarDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Sanskar Reminders", color = colorGreen, fontWeight = FontWeight.Bold)
                    Row {
                        IconButton(onClick = { showAddSanskarDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = colorGreen)
                        }
                        IconButton(onClick = { showSanskarSettingsDialog = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = colorYellow)
                        }
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Active Hours: ${sanskarStartHour}:00 - ${sanskarEndHour}:00 | Dismiss: $sanskarDismissOpt",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    if (sanskarList.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No Sanskar chimes yet. Tap + to add one!", color = Color.Gray, fontSize = 12.sp)
                        }
                    } else {
                        sanskarList.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF181B22), RoundedCornerShape(10.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Every ${item.intervalMin}m", color = colorGreen, fontSize = 11.sp)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        val updated = sanskarList.filter { it.id != item.id }
                                        sanskarList = updated.toMutableList()
                                        prefs.saveSanskarList(updated)
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(18.dp))
                                    }
                                    Switch(
                                        checked = item.active,
                                        onCheckedChange = { active ->
                                            val updated = sanskarList.map {
                                                if (it.id == item.id) it.copy(active = active) else it
                                            }
                                            sanskarList = updated.toMutableList()
                                            prefs.saveSanskarList(updated)
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Test Chime Alert Button
                    OutlinedButton(
                        onClick = {
                            val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                putExtra("TITLE", "Test Sanskar Reminder")
                                putExtra("TYPE", "SANSKAR")
                                putExtra("DISMISS_OPT", sanskarDismissOpt)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(testIntent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Sanskar Lock-Screen Alert", color = colorGreen, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSanskarDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF121418)
        )
    }

    // 3B. ADD SANSKAR DIALOG (TITLE + FREE FLOW INTERVAL)
    if (showAddSanskarDialog) {
        var sTitle by remember { mutableStateOf("") }
        var sInterval by remember { mutableIntStateOf(15) }

        AlertDialog(
            onDismissRequest = { showAddSanskarDialog = false },
            title = { Text("Add New Sanskar", color = colorGreen, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = sTitle,
                        onValueChange = { sTitle = it },
                        label = { Text("Sanskar Title (e.g. Mindful Chime)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text("Chime Interval: $sInterval Minutes", color = Color.White, fontSize = 13.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(onClick = { if (sInterval > 1) sInterval-- }) { Text("-1m") }
                        Button(onClick = { if (sInterval > 5) sInterval -= 5 else sInterval = 1 }) { Text("-5m") }
                        Text("$sInterval m", color = colorYellow, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Button(onClick = { if (sInterval < 180) sInterval += 5 }) { Text("+5m") }
                        Button(onClick = { if (sInterval < 180) sInterval += 15 }) { Text("+15m") }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (sTitle.isNotBlank()) {
                            val newItem = SanskarItem(
                                title = sTitle,
                                intervalMin = sInterval,
                                active = true,
                                startHour = sanskarStartHour,
                                endHour = sanskarEndHour
                            )
                            val updated = sanskarList.toMutableList().apply { add(newItem) }
                            sanskarList = updated
                            prefs.saveSanskarList(updated)
                            showAddSanskarDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = colorGreen)
                ) {
                    Text("Create Sanskar", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSanskarDialog = false }) { Text("Cancel", color = Color.Gray) }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 3C. SANSKAR SETTINGS DIALOG (DISMISS OPTIONS + ACTIVE HOURS 5AM - 9PM)
    if (showSanskarSettingsDialog) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")

        AlertDialog(
            onDismissRequest = { showSanskarSettingsDialog = false },
            title = { Text("Sanskar Gear Settings", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text("Auto-Dismiss Alert:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = sanskarDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    sanskarDismissOpt = opt
                                    prefs.setSanskarDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = colorYellow,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }
                    Text(
                        text = if (sanskarDismissOpt == "OFF") "OFF: Rings until user manually closes" else "Auto shuts off after $sanskarDismissOpt",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )

                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))

                    Text("Active Chime Hours (Defined Day Window):", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Start: ${sanskarStartHour}:00", color = Color.White, fontSize = 12.sp)
                        Row {
                            Button(onClick = { if (sanskarStartHour > 0) sanskarStartHour--; prefs.setSanskarStartHour(sanskarStartHour) }) { Text("-") }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(onClick = { if (sanskarStartHour < sanskarEndHour) sanskarStartHour++; prefs.setSanskarStartHour(sanskarStartHour) }) { Text("+") }
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("End: ${sanskarEndHour}:00", color = Color.White, fontSize = 12.sp)
                        Row {
                            Button(onClick = { if (sanskarEndHour > sanskarStartHour) sanskarEndHour--; prefs.setSanskarEndHour(sanskarEndHour) }) { Text("-") }
                            Spacer(modifier = Modifier.width(4.dp))
                            Button(onClick = { if (sanskarEndHour < 23) sanskarEndHour++; prefs.setSanskarEndHour(sanskarEndHour) }) { Text("+") }
                        }
                    }
                    Text(
                        text = "Sanskar chimes will only ring between ${sanskarStartHour}:00 and ${sanskarEndHour}:00 (safe at night).",
                        color = colorGreen,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSanskarSettingsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = colorYellow)
                ) {
                    Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 4. SANKALP DIALOG
    if (showSankalpSheet) {
        AlertDialog(
            onDismissRequest = { showSankalpSheet = false },
            title = { Text("Sankalp Daily Resolutions", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    trackerList.forEach { item ->
                        val isMarkedToday = item.lastCheckedEpochDay == currentEpochDay
                        val totalProgress = if (item.targetDays > 0) item.completedDays.toFloat() / item.targetDays.toFloat() else 0f
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Day ${item.completedDays} of ${item.targetDays}", color = Color.Gray, fontSize = 11.sp)
                                }
                                if (isMarkedToday) {
                                    FilledTonalButton(onClick = {}, enabled = false) {
                                        Text("Done", fontSize = 11.sp)
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            val updated = trackerList.map {
                                                if (it.id == item.id) it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                                                else it
                                            }
                                            trackerList = updated.toMutableList()
                                            prefs.saveTrackerList(updated)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = colorYellow)
                                    ) {
                                        Text("Check", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = totalProgress,
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                                color = colorYellow,
                                trackColor = Color(0xFF262A34)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSankalpSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 5. ALARMS SHEET
    if (showAlarmsSheet) {
        var showAddAlarm by remember { mutableStateOf(false) }
        var newTitle by remember { mutableStateOf("") }
        var newHour by remember { mutableIntStateOf(6) }
        var newMin by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { showAlarmsSheet = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Exact Alarms", color = colorGreen, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { showAddAlarm = !showAddAlarm }) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = colorGreen)
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (showAddAlarm) {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Alarm Name") },
                            singleLine = true
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Time: ${String.format(Locale.getDefault(), "%02d:%02d", newHour, newMin)}", color = Color.White)
                            Row {
                                Button(onClick = { newHour = (newHour + 1) % 24 }) { Text("+1h") }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(onClick = { newMin = (newMin + 15) % 60 }) { Text("+15m") }
                            }
                        }
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    val item = NiyamItem(title = newTitle, hour = newHour, minute = newMin, active = true)
                                    val updated = niyamList.toMutableList().apply { add(item) }
                                    niyamList = updated
                                    prefs.saveNiyamList(updated)
                                    newTitle = ""
                                    showAddAlarm = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = colorGreen)
                        ) {
                            Text("Save Alarm", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    }

                    niyamList.forEach { item ->
                        val rh = if (item.hour % 12 == 0) 12 else item.hour % 12
                        val amPm = if (item.hour >= 12) "PM" else "AM"
                        val timeStr = String.format(Locale.getDefault(), "%02d:%02d %s", rh, item.minute, amPm)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text(timeStr, color = colorGreen, fontSize = 11.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val updated = niyamList.filter { it.id != item.id }
                                    niyamList = updated.toMutableList()
                                    prefs.saveNiyamList(updated)
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                                Switch(
                                    checked = item.active,
                                    onCheckedChange = { active ->
                                        val updated = niyamList.map {
                                            if (it.id == item.id) it.copy(active = active) else it
                                        }
                                        niyamList = updated.toMutableList()
                                        prefs.saveNiyamList(updated)
                                    }
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                putExtra("TITLE", "Test Sacred Alarm")
                                putExtra("TYPE", "NIYAM")
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(testIntent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Lock-Screen Alarm Alert", color = colorGreen, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAlarmsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 6. NOTES SHEET
    if (showNotesSheet) {
        var notes by remember { mutableStateOf(prefs.getNotes()) }
        var newNoteText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNotesSheet = false },
            title = { Text("Sacred Notes & Diary", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newNoteText,
                        onValueChange = { newNoteText = it },
                        label = { Text("Write reflection...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (newNoteText.isNotBlank()) {
                                val item = NoteItem(text = newNoteText)
                                val updated = notes.toMutableList().apply { add(0, item) }
                                notes = updated
                                prefs.saveNotes(updated)
                                newNoteText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = colorYellow),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Note", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    notes.take(5).forEach { note ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(note.text, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val updated = notes.filter { it.id != note.id }
                                notes = updated.toMutableList()
                                prefs.saveNotes(updated)
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showNotesSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 7. LOGS SHEET
    if (showLogsSheet) {
        val logs = prefs.getLogs()
        AlertDialog(
            onDismissRequest = { showLogsSheet = false },
            title = { Text("Daily History & Logs", color = colorGreen, fontWeight = FontWeight.Bold) },
            text = {
                if (logs.isEmpty()) {
                    Text("No logs recorded yet.", color = Color.Gray)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        logs.take(8).forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(log.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("${log.timeStr} • ${log.type}", color = Color.Gray, fontSize = 10.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(colorGreen.copy(alpha = 0.2f), CircleShape)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(text = log.status, color = colorGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showLogsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 8. PLANNER SHEET
    if (showPlannerSheet) {
        var plannerEvents by remember { mutableStateOf(prefs.getPlannerEvents()) }
        AlertDialog(
            onDismissRequest = { showPlannerSheet = false },
            title = { Text("Routine & Planner", color = colorYellow, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (plannerEvents.isEmpty()) {
                        Text("No upcoming events in planner.", color = Color.Gray)
                    } else {
                        plannerEvents.forEach { ev ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ev.title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(String.format(Locale.getDefault(), "%02d:%02d", ev.hour, ev.minute), color = colorYellow, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showPlannerSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorYellow)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 9. APP SETTINGS SHEET
    if (showSettingsSheet) {
        AlertDialog(
            onDismissRequest = { showSettingsSheet = false },
            title = { Text("App Preferences", color = colorGreen, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Version: 1.2.0 (Themed Green & Yellow Black Edition)", color = Color.Gray, fontSize = 11.sp)
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Manage App Permissions", color = Color.White, fontSize = 11.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSettingsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = colorGreen)) {
                    Text("Close", color = Color.Black)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }
}

// =========================================================================
// 3x3 COMPACT GRID TILE COMPOSABLE (THEMED GREEN & YELLOW ON BLACK)
// =========================================================================
@Composable
fun GridDashboardTile(
    title: String,
    badge: String,
    subtitle: String,
    accentColor: Color,
    icon: ImageVector,
    isTwoAction: Boolean,
    action1Icon: ImageVector = Icons.Default.PlayArrow,
    action1Label: String = "PLAY",
    action2Icon: ImageVector = Icons.Default.Settings,
    action2Label: String = "SET",
    onAction1: () -> Unit = {},
    onAction2: () -> Unit = {},
    onTileClick: () -> Unit = {},
    isRunning: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF121418)),
        modifier = Modifier
            .fillMaxWidth()
            .height(138.dp)
            .border(1.5.dp, if (isRunning) Color(0xFFFF5252) else accentColor.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            .clickable { onTileClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // TOP ROW: ICON + BADGE
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(15.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .background(accentColor.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = badge,
                        color = accentColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // MIDDLE INFO: TITLE + SUBTITLE
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    color = if (isRunning) Color(0xFFFF5252) else Color.Gray,
                    fontSize = 9.sp,
                    fontWeight = if (isRunning) FontWeight.Bold else FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // BOTTOM ACTION ROW
            if (isTwoAction) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Button 1 (PLAY / STOP / ADD / CHK)
                    Surface(
                        onClick = onAction1,
                        shape = CircleShape,
                        color = if (isRunning) Color(0xFFFF5252) else accentColor,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = action1Icon,
                                contentDescription = action1Label,
                                tint = Color.Black,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Button 2 (SETTING GEAR)
                    Surface(
                        onClick = onAction2,
                        shape = CircleShape,
                        color = Color(0xFFFFB300),
                        modifier = Modifier.size(30.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = action2Icon,
                                contentDescription = action2Label,
                                tint = Color.Black,
                                modifier = Modifier.size(15.dp)
                            )
                        }
                    }
                }
            } else {
                // Navigation Chevron Button
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        onClick = onTileClick,
                        shape = CircleShape,
                        color = accentColor.copy(alpha = 0.25f),
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowRight,
                                contentDescription = "Open",
                                tint = accentColor,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

fun formatDurationSec(sec: Int): String {
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return when {
        h > 0 && m > 0 -> "${h}h ${m}m"
        h > 0 -> "${h}h"
        m > 0 && s > 0 -> "${m}m ${s}s"
        m > 0 -> "${m}m"
        else -> "${s}s"
    }
}

@Composable
fun KriyaDurationRow(label: String, valueSec: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { if (valueSec > 1) onValueChange(valueSec - 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("-", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("${valueSec}s", color = Color(0xFFFFB300), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalButton(
                onClick = { if (valueSec < 60) onValueChange(valueSec + 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("+", fontWeight = FontWeight.Bold)
            }
        }
    }
}

