package com.mratubhayas.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(prefs: AppPreferences) {
    val context = LocalContext.current

    // Live Clock Ticker
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(now)
            currentDate = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(now)
            delay(1000L)
        }
    }

    // ================= 1. DHYAN STATE =================
    var dhyanRunning by remember { mutableStateOf(false) }
    var dhyanTargetMin by remember { mutableIntStateOf(prefs.getDhyanDurationMin()) }
    var dhyanElapsedSec by remember { mutableIntStateOf(0) }
    var showDhyanSettings by remember { mutableStateOf(false) }
    var dhyanDismissOpt by remember { mutableStateOf(prefs.getDhyanDismissOption()) }
    var dhyanToneUri by remember { mutableStateOf(prefs.getDhyanToneUri()) }
    var dhyanToneIdx by remember { mutableIntStateOf(prefs.getDhyanToneIndex()) }

    // Ringtone Picker Launcher
    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            dhyanToneUri = uri?.toString()
            prefs.setDhyanToneUri(dhyanToneUri)
        }
    }

    // Dhyan Timer Runner: 1s, 2s ... 45m
    LaunchedEffect(dhyanRunning) {
        if (dhyanRunning) {
            dhyanElapsedSec = 0
            val totalSec = dhyanTargetMin * 60
            prefs.scheduleDhyanAlarm(totalSec) // Exact background alarm
            while (dhyanRunning && dhyanElapsedSec < totalSec) {
                delay(1000L)
                dhyanElapsedSec += 1
            }
            if (dhyanRunning && dhyanElapsedSec >= totalSec) {
                dhyanRunning = false
                // Trigger Lock-Screen Alert Activity with Ant Running circle and Tone
                val intent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", "Dhyan Meditation Completed!")
                    putExtra("TYPE", "DHYAN")
                    putExtra("DISMISS_OPT", dhyanDismissOpt)
                    putExtra("TONE_URI", dhyanToneUri)
                    putExtra("TONE_IDX", dhyanToneIdx)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                context.startActivity(intent)
            }
        } else {
            prefs.cancelDhyanAlarm()
        }
    }

    // ================= 2. KRIYA YOGA (BOX PRANAYAMA) STATE =================
    var kriyaRunning by remember { mutableStateOf(false) }
    var kriyaInhaleSec by remember { mutableIntStateOf(prefs.getKriyaInhaleSec()) }
    var kriyaHoldInSec by remember { mutableIntStateOf(prefs.getKriyaHoldInSec()) }
    var kriyaExhaleSec by remember { mutableIntStateOf(prefs.getKriyaExhaleSec()) }
    var kriyaHoldOutSec by remember { mutableIntStateOf(prefs.getKriyaHoldOutSec()) }
    var kriyaPhase by remember { mutableIntStateOf(0) } // 0: Inhale, 1: Hold In, 2: Exhale, 3: Hold Out
    var kriyaSecLeft by remember { mutableIntStateOf(4) }
    var kriyaCycles by remember { mutableIntStateOf(0) }
    var showKriyaSettings by remember { mutableStateOf(false) }
    var showKriyaVisualizer by remember { mutableStateOf(false) }

    val phaseNames = listOf("INHALE", "HOLD IN", "EXHALE", "HOLD OUT")

    // Kriya Breathing Scale Animation
    val targetScale = when (kriyaPhase) {
        0 -> 1.4f // Inhale expands
        1 -> 1.4f // Hold In
        2 -> 1.0f // Exhale contracts
        else -> 1.0f // Hold Out
    }
    val animatedKriyaScale by animateFloatAsState(
        targetValue = if (kriyaRunning) targetScale else 1.0f,
        animationSpec = tween(
            durationMillis = if (kriyaRunning) {
                when (kriyaPhase) {
                    0 -> kriyaInhaleSec * 1000
                    1 -> kriyaHoldInSec * 1000
                    2 -> kriyaExhaleSec * 1000
                    else -> kriyaHoldOutSec * 1000
                }
            } else 350,
            easing = LinearEasing
        ),
        label = "KriyaBreathingScale"
    )

    // Kriya Runner
    LaunchedEffect(kriyaRunning) {
        if (kriyaRunning) {
            kriyaPhase = 0
            kriyaCycles = 0
            while (kriyaRunning) {
                val durations = listOf(kriyaInhaleSec, kriyaHoldInSec, kriyaExhaleSec, kriyaHoldOutSec)
                val curDur = durations[kriyaPhase].coerceAtLeast(1)
                NokiaToneEngine.playBeep(440 + (kriyaPhase * 220), 80)
                for (s in curDur downTo 1) {
                    if (!kriyaRunning) break
                    kriyaSecLeft = s
                    delay(1000L)
                }
                if (kriyaPhase == 3) kriyaCycles += 1
                kriyaPhase = (kriyaPhase + 1) % 4
            }
        }
    }

    // ================= MODAL SHEETS & DIALOGS STATE =================
    var showSanskarSettings by remember { mutableStateOf(false) }
    var showSankalpSheet by remember { mutableStateOf(false) }
    var showAlarmsSheet by remember { mutableStateOf(false) }
    var showNotesSheet by remember { mutableStateOf(false) }
    var showLogsSheet by remember { mutableStateOf(false) }
    var showPlannerSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }

    // Repositories
    var niyamList by remember { mutableStateOf(prefs.getNiyamList()) }
    var sanskarList by remember { mutableStateOf(prefs.getSanskarList()) }
    var trackerList by remember { mutableStateOf(prefs.getTrackerList()) }
    val currentEpochDay = System.currentTimeMillis() / (86400 * 1000L)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090A0F))
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp),
            contentPadding = PaddingValues(top = 14.dp, bottom = 44.dp)
        ) {
            // TOP HEADER: BRAND & DIGITAL CLOCK
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MRATUBHAYAS",
                            color = Color(0xFFFFB300),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 3.sp
                        )
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF161922), RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "ACTIVE ENGINE",
                                color = Color(0xFF00E5FF),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = currentDate.uppercase(),
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = currentTime,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // ================= TILE 1: DHYAN (PURPLE) =================
            item {
                val totalSec = dhyanTargetMin * 60
                val progress = if (totalSec > 0) dhyanElapsedSec.toFloat() / totalSec.toFloat() else 0f
                val remainingSec = (totalSec - dhyanElapsedSec).coerceAtLeast(0)
                val displayMin = remainingSec / 60
                val displaySec = remainingSec % 60
                val elapsedMin = dhyanElapsedSec / 60
                val elapsedSec = dhyanElapsedSec % 60

                CurvedDashboardTile(
                    title = "Dhyan",
                    badgeText = "ध्यान • MIND",
                    subtitle = if (!dhyanRunning) "Meditation & Mindfulness (${dhyanTargetMin}m)"
                    else "Timer: ${String.format(Locale.getDefault(), "%02d:%02d", displayMin, displaySec)} (Elapsed: ${String.format(Locale.getDefault(), "%02d:%02d", elapsedMin, elapsedSec)})",
                    gradientColors = listOf(Color(0xFF5B21B6), Color(0xFF7C3AED), Color(0xFF9333EA)),
                    icon = Icons.Default.PlayArrow,
                    isTwoAction = true,
                    action1Icon = if (dhyanRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (dhyanRunning) "STOP" else "PLAY",
                    onAction1 = { dhyanRunning = !dhyanRunning },
                    onAction2 = { showDhyanSettings = true },
                    onCardClick = { showDhyanSettings = true },
                    liveContent = if (dhyanRunning) {
                        {
                            LinearProgressIndicator(
                                progress = progress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(CircleShape),
                                color = Color.White,
                                trackColor = Color.White.copy(alpha = 0.25f)
                            )
                        }
                    } else null
                )
            }

            // ================= TILE 2: KRIYA YOG (EMERALD) =================
            item {
                CurvedDashboardTile(
                    title = "Kriya Yog",
                    badgeText = "क्रिया योग • PRANAYAMA",
                    subtitle = if (!kriyaRunning) "Discipline & Daily Habits (${kriyaInhaleSec}s-${kriyaHoldInSec}s-${kriyaExhaleSec}s-${kriyaHoldOutSec}s)"
                    else "Phase: ${phaseNames[kriyaPhase]} (${kriyaSecLeft}s) • Round: $kriyaCycles",
                    gradientColors = listOf(Color(0xFF047857), Color(0xFF059669), Color(0xFF10B981)),
                    icon = Icons.Default.Refresh,
                    isTwoAction = true,
                    action1Icon = if (kriyaRunning) Icons.Default.Close else Icons.Default.PlayArrow,
                    action1Label = if (kriyaRunning) "STOP" else "PLAY",
                    onAction1 = { kriyaRunning = !kriyaRunning },
                    onAction2 = { showKriyaSettings = true },
                    onCardClick = { showKriyaVisualizer = true },
                    liveContent = if (kriyaRunning) {
                        {
                            Text(
                                text = "Cycles completed: $kriyaCycles • Inhale $kriyaInhaleSec s / Exhale $kriyaExhaleSec s",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    } else null
                )
            }

            // ================= TILE 3: SANSKAR (AMBER / ORANGE) =================
            item {
                CurvedDashboardTile(
                    title = "Sanskar",
                    badgeText = "संस्कार • VALUES",
                    subtitle = "Ethics, Culture & Wisdom • Mindful Chimes",
                    gradientColors = listOf(Color(0xFFB45309), Color(0xFFD97706), Color(0xFFF59E0B)),
                    icon = Icons.Default.Notifications,
                    isTwoAction = true,
                    action1Icon = Icons.Default.Notifications,
                    action1Label = "CHIME",
                    onAction1 = { NokiaToneEngine.playTone(0, loop = false) },
                    onAction2 = { showSanskarSettings = true },
                    onCardClick = { showSanskarSettings = true }
                )
            }

            // ================= TILE 4: SANKALP (CRIMSON / RED) =================
            item {
                CurvedDashboardTile(
                    title = "Sankalp",
                    badgeText = "संकल्प • GOALS",
                    subtitle = "Resolutions & Vows • Daily Sadhana",
                    gradientColors = listOf(Color(0xFFB91C1C), Color(0xFFDC2626), Color(0xFFEF4444)),
                    icon = Icons.Default.Check,
                    isTwoAction = true,
                    action1Icon = Icons.Default.Check,
                    action1Label = "CHECK",
                    onAction1 = {
                        val updated = trackerList.map {
                            if (it.lastCheckedEpochDay != currentEpochDay) {
                                it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                            } else it
                        }
                        trackerList = updated.toMutableList()
                        prefs.saveTrackerList(updated)
                    },
                    onAction2 = { showSankalpSheet = true },
                    onCardClick = { showSankalpSheet = true }
                )
            }

            // ================= TILE 5: ALARM (GOLD / YELLOW) =================
            item {
                CurvedDashboardTile(
                    title = "Alarm",
                    badgeText = "अलार्म • ALERT",
                    subtitle = "Wake-Up & Sacred Timers (${niyamList.count { it.active }} Active)",
                    gradientColors = listOf(Color(0xFFA16207), Color(0xFFCA8A04), Color(0xFFEAB308)),
                    icon = Icons.Default.Notifications,
                    isTwoAction = false,
                    onCardClick = { showAlarmsSheet = true }
                )
            }

            // ================= TILE 6: NOTES (OCEAN BLUE) =================
            item {
                CurvedDashboardTile(
                    title = "Notes",
                    badgeText = "नोट्स • DIARY",
                    subtitle = "Reflections & Thoughts (${prefs.getNotes().size} Saved)",
                    gradientColors = listOf(Color(0xFF0369A1), Color(0xFF0284C7), Color(0xFF0EA5E9)),
                    icon = Icons.Default.Edit,
                    isTwoAction = false,
                    onCardClick = { showNotesSheet = true }
                )
            }

            // ================= TILE 7: LOGS (MAGENTA / VIOLET) =================
            item {
                CurvedDashboardTile(
                    title = "Logs",
                    badgeText = "लॉग्स • HISTORY",
                    subtitle = "Daily Records & History (${prefs.getLogs().size} Entries)",
                    gradientColors = listOf(Color(0xFF7E22CE), Color(0xFF9333EA), Color(0xFFA855F7)),
                    icon = Icons.Default.Star,
                    isTwoAction = false,
                    onCardClick = { showLogsSheet = true }
                )
            }

            // ================= TILE 8: PLANNER (TEAL) =================
            item {
                CurvedDashboardTile(
                    title = "Planner",
                    badgeText = "प्लानर • PLAN",
                    subtitle = "Routine & Schedules",
                    gradientColors = listOf(Color(0xFF0F766E), Color(0xFF0D9488), Color(0xFF14B8A6)),
                    icon = Icons.Default.DateRange,
                    isTwoAction = false,
                    onCardClick = { showPlannerSheet = true }
                )
            }

            // ================= TILE 9: SETTING (ROSE / RUBY) =================
            item {
                CurvedDashboardTile(
                    title = "Setting",
                    badgeText = "सेटिंग • CONFIG",
                    subtitle = "Preferences & Controls",
                    gradientColors = listOf(Color(0xFFBE123C), Color(0xFFE11D48), Color(0xFFF43F5E)),
                    icon = Icons.Default.Settings,
                    isTwoAction = false,
                    onCardClick = { showSettingsSheet = true }
                )
            }
        }
    }

    // =========================================================================
    // MODAL DIALOGS & ACTION SHEETS
    // =========================================================================

    // 1. DHYAN SETTINGS DIALOG
    if (showDhyanSettings) {
        val dismissOptions = listOf("OFF", "10S", "20S", "40S", "1M")
        val nokiaMelodyNames = listOf("Nokia Intro", "SMS Special", "Nostalgia", "William Tell", "Polka")

        AlertDialog(
            onDismissRequest = { showDhyanSettings = false },
            title = {
                Text("Dhyan Meditation Settings", color = Color(0xFF9D4EDD), fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // DURATION CONFIG
                    Text("Target Meditation Duration:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilledTonalButton(
                            onClick = {
                                if (dhyanTargetMin > 5) {
                                    dhyanTargetMin -= 5
                                    prefs.setDhyanDurationMin(dhyanTargetMin)
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("- 5m", fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Text(
                            text = "${dhyanTargetMin} min",
                            color = Color.White,
                            fontSize = 26.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        FilledTonalButton(
                            onClick = {
                                dhyanTargetMin += 5
                                prefs.setDhyanDurationMin(dhyanTargetMin)
                            },
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("+ 5m", fontWeight = FontWeight.Bold)
                        }
                    }

                    // AUTO DISMISS TIMEOUT
                    Text("Auto-Dismiss Alert Timeout:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        dismissOptions.forEach { opt ->
                            val isSel = dhyanDismissOpt == opt
                            FilterChip(
                                selected = isSel,
                                onClick = {
                                    dhyanDismissOpt = opt
                                    prefs.setDhyanDismissOption(opt)
                                },
                                label = { Text(opt, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF9D4EDD),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                    Text(
                        text = if (dhyanDismissOpt == "OFF") "Continuous ringing until user manually stops" else "Auto shuts off after $dhyanDismissOpt",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    // ALERT SOUND SELECTION
                    Text("Alert Sound Selection:", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        nokiaMelodyNames.forEachIndexed { idx, name ->
                            val isSelected = dhyanToneIdx == idx && dhyanToneUri == null
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        dhyanToneIdx = idx
                                        dhyanToneUri = null
                                        prefs.setDhyanToneIndex(idx)
                                        prefs.setDhyanToneUri(null)
                                        NokiaToneEngine.playTone(idx, loop = false)
                                    }
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(name, color = if (isSelected) Color(0xFF00E5FF) else Color.White, fontSize = 13.sp)
                                if (isSelected) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    // Custom Ringtone / Audio Picker from Phone Gallery
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Alert Sound")
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                            }
                            ringtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = if (dhyanToneUri != null) "Custom Sound Selected" else "Choose from Phone Storage",
                            color = Color(0xFFFFB300),
                            fontSize = 12.sp
                        )
                    }

                    // Test Alert Button
                    Button(
                        onClick = {
                            val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                putExtra("TITLE", "Test Dhyan Meditation Completed!")
                                putExtra("TYPE", "DHYAN")
                                putExtra("DISMISS_OPT", dhyanDismissOpt)
                                putExtra("TONE_URI", dhyanToneUri)
                                putExtra("TONE_IDX", dhyanToneIdx)
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(testIntent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Notifications, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Lock-Screen Alert Now", color = Color(0xFFFFB300), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showDhyanSettings = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9D4EDD))
                ) {
                    Text("Save", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 2. KRIYA YOGA BREATHING SETTINGS DIALOG
    if (showKriyaSettings) {
        AlertDialog(
            onDismissRequest = { showKriyaSettings = false },
            title = {
                Text("Kriya Yoga (Breath Seconds)", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    KriyaDurationRow("Breath In Time", kriyaInhaleSec) {
                        kriyaInhaleSec = it
                        prefs.setKriyaInhaleSec(it)
                    }
                    KriyaDurationRow("Hold In Time", kriyaHoldInSec) {
                        kriyaHoldInSec = it
                        prefs.setKriyaHoldInSec(it)
                    }
                    KriyaDurationRow("Breath Out Time", kriyaExhaleSec) {
                        kriyaExhaleSec = it
                        prefs.setKriyaExhaleSec(it)
                    }
                    KriyaDurationRow("Hold Out Time", kriyaHoldOutSec) {
                        kriyaHoldOutSec = it
                        prefs.setKriyaHoldOutSec(it)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showKriyaSettings = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Save", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 2B. KRIYA YOGA VISUALIZER DIALOG
    if (showKriyaVisualizer) {
        AlertDialog(
            onDismissRequest = { showKriyaVisualizer = false },
            title = {
                Text("Pranayama Box Breathing", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .scale(animatedKriyaScale),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(160.dp)
                                .background(Color(0xFF10B981).copy(alpha = 0.2f), CircleShape)
                                .border(2.dp, Color(0xFF10B981), CircleShape)
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (kriyaRunning) phaseNames[kriyaPhase] else "READY",
                                color = Color(0xFF10B981),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (kriyaRunning) {
                                Text(
                                    text = "${kriyaSecLeft}s",
                                    color = Color.White,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text("Rounds: $kriyaCycles", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { kriyaRunning = !kriyaRunning },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (kriyaRunning) Color(0xFFFF5252) else Color(0xFF10B981)
                    )
                ) {
                    Text(if (kriyaRunning) "Stop" else "Start", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showKriyaVisualizer = false }) {
                    Text("Close", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 3. SANSKAR CHIMES SETTINGS DIALOG
    if (showSanskarSettings) {
        AlertDialog(
            onDismissRequest = { showSanskarSettings = false },
            title = { Text("Sanskar Mindful Chimes", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    sanskarList.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Every ${item.intervalMin}m (${item.startHour}:00 - ${item.endHour}:00)", color = Color.Gray, fontSize = 11.sp)
                            }
                            Switch(
                                checked = item.active,
                                onCheckedChange = { active ->
                                    val updated = sanskarList.map {
                                        if (it.id == item.id) it.copy(active = active) else it
                                    }
                                    sanskarList = updated.toMutableList()
                                    prefs.saveSanskarList(updated)
                                }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSanskarSettings = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))) {
                    Text("Done", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 4. SANKALP DIALOG
    if (showSankalpSheet) {
        AlertDialog(
            onDismissRequest = { showSankalpSheet = false },
            title = { Text("Sankalp Daily Resolutions", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    trackerList.forEach { item ->
                        val isMarkedToday = item.lastCheckedEpochDay == currentEpochDay
                        val totalProgress = if (item.targetDays > 0) item.completedDays.toFloat() / item.targetDays.toFloat() else 0f
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text("Day ${item.completedDays} of ${item.targetDays}", color = Color.Gray, fontSize = 11.sp)
                                }
                                if (isMarkedToday) {
                                    FilledTonalButton(onClick = {}, enabled = false) {
                                        Text("Done Today", fontSize = 11.sp)
                                    }
                                } else {
                                    Button(
                                        onClick = {
                                            val updated = trackerList.map {
                                                if (it.id == item.id) it.copy(completedDays = it.completedDays + 1, lastCheckedEpochDay = currentEpochDay)
                                                else it
                                            }
                                            trackerList = updated.toMutableList()
                                            prefs.saveTrackerList(updated)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))
                                    ) {
                                        Text("Check", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = totalProgress,
                                modifier = Modifier.fillMaxWidth().height(4.dp).clip(CircleShape),
                                color = Color(0xFFEF4444),
                                trackColor = Color(0xFF262A34)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSankalpSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444))) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 5. ALARMS SHEET
    if (showAlarmsSheet) {
        var showAddAlarm by remember { mutableStateOf(false) }
        var newTitle by remember { mutableStateOf("") }
        var newHour by remember { mutableIntStateOf(6) }
        var newMin by remember { mutableIntStateOf(0) }

        AlertDialog(
            onDismissRequest = { showAlarmsSheet = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Exact Alarms", color = Color(0xFFEAB308), fontWeight = FontWeight.Bold)
                    IconButton(onClick = { showAddAlarm = !showAddAlarm }) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFFEAB308))
                    }
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (showAddAlarm) {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Alarm Name") },
                            singleLine = true
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Time: ${String.format(Locale.getDefault(), "%02d:%02d", newHour, newMin)}", color = Color.White)
                            Row {
                                Button(onClick = { newHour = (newHour + 1) % 24 }) { Text("+1h") }
                                Spacer(modifier = Modifier.width(4.dp))
                                Button(onClick = { newMin = (newMin + 15) % 60 }) { Text("+15m") }
                            }
                        }
                        Button(
                            onClick = {
                                if (newTitle.isNotBlank()) {
                                    val item = NiyamItem(title = newTitle, hour = newHour, minute = newMin, active = true)
                                    val updated = niyamList.toMutableList().apply { add(item) }
                                    niyamList = updated
                                    prefs.saveNiyamList(updated)
                                    newTitle = ""
                                    showAddAlarm = false
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEAB308))
                        ) {
                            Text("Save Alarm", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    }

                    niyamList.forEach { item ->
                        val rh = if (item.hour % 12 == 0) 12 else item.hour % 12
                        val amPm = if (item.hour >= 12) "PM" else "AM"
                        val timeStr = String.format(Locale.getDefault(), "%02d:%02d %s", rh, item.minute, amPm)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(timeStr, color = Color(0xFFEAB308), fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = {
                                    val updated = niyamList.filter { it.id != item.id }
                                    niyamList = updated.toMutableList()
                                    prefs.saveNiyamList(updated)
                                }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                                }
                                Switch(
                                    checked = item.active,
                                    onCheckedChange = { active ->
                                        val updated = niyamList.map {
                                            if (it.id == item.id) it.copy(active = active) else it
                                        }
                                        niyamList = updated.toMutableList()
                                        prefs.saveNiyamList(updated)
                                    }
                                )
                            }
                        }
                    }

                    // Test Alert Button
                    OutlinedButton(
                        onClick = {
                            val testIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                                putExtra("TITLE", "Test Sacred Alarm")
                                putExtra("TYPE", "NIYAM")
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(testIntent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Lock-Screen Alarm Alert", color = Color(0xFFEAB308), fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showAlarmsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEAB308))) {
                    Text("Close", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 6. NOTES SHEET
    if (showNotesSheet) {
        var notes by remember { mutableStateOf(prefs.getNotes()) }
        var newNoteText by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showNotesSheet = false },
            title = { Text("Sacred Notes & Diary", color = Color(0xFF0EA5E9), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newNoteText,
                        onValueChange = { newNoteText = it },
                        label = { Text("Write reflection...") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            if (newNoteText.isNotBlank()) {
                                val item = NoteItem(text = newNoteText)
                                val updated = notes.toMutableList().apply { add(0, item) }
                                notes = updated
                                prefs.saveNotes(updated)
                                newNoteText = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Note", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.Gray.copy(alpha = 0.3f)))
                    notes.take(5).forEach { note ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(note.text, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                val updated = notes.filter { it.id != note.id }
                                notes = updated.toMutableList()
                                prefs.saveNotes(updated)
                            }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showNotesSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0EA5E9))) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 7. LOGS SHEET
    if (showLogsSheet) {
        val logs = prefs.getLogs()
        AlertDialog(
            onDismissRequest = { showLogsSheet = false },
            title = { Text("Daily History & Logs", color = Color(0xFFA855F7), fontWeight = FontWeight.Bold) },
            text = {
                if (logs.isEmpty()) {
                    Text("No logs recorded yet.", color = Color.Gray)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        logs.take(8).forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(log.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("${log.timeStr} • ${log.type}", color = Color.Gray, fontSize = 11.sp)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when (log.status) {
                                                "DONE" -> Color(0xFF10B981).copy(alpha = 0.2f)
                                                "SNOOZED" -> Color(0xFFFFB300).copy(alpha = 0.2f)
                                                else -> Color(0xFFFF5252).copy(alpha = 0.2f)
                                            },
                                            CircleShape
                                        )
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = log.status,
                                        color = when (log.status) {
                                            "DONE" -> Color(0xFF10B981)
                                            "SNOOZED" -> Color(0xFFFFB300)
                                            else -> Color(0xFFFF5252)
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showLogsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFA855F7))) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 8. PLANNER SHEET
    if (showPlannerSheet) {
        var plannerEvents by remember { mutableStateOf(prefs.getPlannerEvents()) }
        AlertDialog(
            onDismissRequest = { showPlannerSheet = false },
            title = { Text("Daily Routine & Planner", color = Color(0xFF14B8A6), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (plannerEvents.isEmpty()) {
                        Text("No upcoming events in planner.", color = Color.Gray)
                    } else {
                        plannerEvents.forEach { ev ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ev.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(String.format(Locale.getDefault(), "%02d:%02d", ev.hour, ev.minute), color = Color(0xFF14B8A6), fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showPlannerSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF14B8A6))) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }

    // 9. APP SETTINGS SHEET
    if (showSettingsSheet) {
        AlertDialog(
            onDismissRequest = { showSettingsSheet = false },
            title = { Text("Preferences & System", color = Color(0xFFF43F5E), fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("App Version: 1.1.0 (ESP32 MratuBhayas Architecture)", color = Color.Gray, fontSize = 12.sp)
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF262A34)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Manage App Permissions", color = Color.White, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showSettingsSheet = false }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF43F5E))) {
                    Text("Close", color = Color.White)
                }
            },
            containerColor = Color(0xFF161922)
        )
    }
}

// =========================================================================
// REUSABLE DASHBOARD CURVED TILE COMPOSABLE (EXACT TO MOCKUP)
// =========================================================================
@Composable
fun CurvedDashboardTile(
    title: String,
    badgeText: String,
    subtitle: String,
    gradientColors: List<Color>,
    icon: ImageVector,
    isTwoAction: Boolean,
    action1Icon: ImageVector = Icons.Default.PlayArrow,
    action1Label: String = "PLAY",
    onAction1: () -> Unit = {},
    onAction2: () -> Unit = {},
    onCardClick: () -> Unit = {},
    liveContent: (@Composable () -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(26.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(if (liveContent != null) 152.dp else 136.dp)
            .clickable { onCardClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.horizontalGradient(gradientColors))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 18.dp, top = 14.dp, bottom = 14.dp, end = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // LEFT CONTENT (Title, Badge, Subtitle, Live Timer)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    // Top row: Frosted Icon Container + Pill Badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(Color.White.copy(alpha = 0.22f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(19.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Box(
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.38f), CircleShape)
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = badgeText,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    // Bottom info: Title, Subtitle, Live Bar
                    Column {
                        Text(
                            text = title,
                            color = Color.White,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = subtitle,
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            maxLines = 1
                        )
                        if (liveContent != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            liveContent()
                        }
                    }
                }

                // VERTICAL DIVIDER
                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .fillMaxHeight()
                        .padding(vertical = 10.dp, horizontal = 4.dp)
                        .background(Color.White.copy(alpha = 0.22f))
                )

                // RIGHT ACTIONS
                if (isTwoAction) {
                    Column(
                        modifier = Modifier
                            .width(68.dp)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Button 1 (PLAY / STOP / CHECK)
                        Surface(
                            onClick = onAction1,
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(38.dp),
                            shadowElevation = 3.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = action1Icon,
                                    contentDescription = action1Label,
                                    tint = gradientColors.first(),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Text(
                            text = action1Label,
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Button 2 (SETTING)
                        Surface(
                            onClick = onAction2,
                            shape = CircleShape,
                            color = Color.White,
                            modifier = Modifier.size(38.dp),
                            shadowElevation = 3.dp
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Settings,
                                    contentDescription = "Setting",
                                    tint = gradientColors.first(),
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                        Text(
                            text = "SETTING",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.8.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                } else {
                    // 1-Action Chevron Button
                    Box(
                        modifier = Modifier
                            .width(56.dp)
                            .fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            onClick = onCardClick,
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.28f),
                            modifier = Modifier.size(42.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.KeyboardArrowRight,
                                    contentDescription = "Open",
                                    tint = Color.White,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KriyaDurationRow(label: String, valueSec: Int, onValueChange: (Int) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            FilledTonalButton(
                onClick = { if (valueSec > 1) onValueChange(valueSec - 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("-", fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("${valueSec}s", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Spacer(modifier = Modifier.width(8.dp))
            FilledTonalButton(
                onClick = { if (valueSec < 30) onValueChange(valueSec + 1) },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text("+", fontWeight = FontWeight.Bold)
            }
        }
    }
}

