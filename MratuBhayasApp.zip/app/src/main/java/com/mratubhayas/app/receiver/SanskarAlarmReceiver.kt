package com.mratubhayas.app.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.R
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.AppPreferences
import java.util.*

class SanskarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("TITLE") ?: "Sanskar Reminder"
        val sanskarId = intent.getLongExtra("SANSKAR_ID", 0L)
        val prefs = AppPreferences(context)

        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val sanskar = prefs.getSanskarList().find { it.id == sanskarId }
            ?: prefs.getSanskarList().firstOrNull { it.active }

        if (sanskar != null && sanskar.active) {
            val startH = prefs.getSanskarStartHour()
            val endH = prefs.getSanskarEndHour()
            val inWindow = if (startH <= endH) {
                currentHour in startH..endH
            } else {
                currentHour >= startH || currentHour <= endH
            }

            if (inWindow) {
                // 1. Acquire WakeLock so CPU doesn't sleep
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                val wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "MratuBhayas:SanskarWakeLock"
                )
                wakeLock.acquire(30000L)

                // 2. Play Chime Immediately so sound is heard even if screen takes a second to wake
                NokiaToneEngine.playTone(0, loop = false)

                // 3. Launch Full-Screen Lock Screen Alarm Activity
                val dismissOpt = prefs.getSanskarDismissOption()
                val fullScreenIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", sanskar.title)
                    putExtra("TYPE", "SANSKAR")
                    putExtra("DISMISS_OPT", dismissOpt)
                    putExtra("TONE_IDX", 0)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }

                val reqCode = (Math.abs(sanskar.id.hashCode()) % 40000) + 20000
                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    reqCode,
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // 4. Post High Priority Notification with Full Screen Intent (Wakes Lockscreen)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channelId = "sanskar_channel_v2"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        channelId,
                        "Sanskar Chimes",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Mindful periodic reminder chimes"
                        enableVibration(true)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                val notification = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("MratuBhayas Sanskar")
                    .setContentText(sanskar.title)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)
                    .build()

                notificationManager.notify(reqCode, notification)

                try {
                    context.startActivity(fullScreenIntent)
                } catch (e: Exception) {}
            }

            // 5. Always Reschedule Next Interval
            prefs.scheduleSanskarAlarm(sanskar)
        }
    }
}
