package com.mratubhayas.app.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.R
import com.mratubhayas.app.model.AppPreferences
import java.util.*

class SanskarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("TITLE") ?: "Sanskar Reminder"
        val sanskarId = intent.getLongExtra("SANSKAR_ID", 0L)
        val prefs = AppPreferences(context)

        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val sanskar = prefs.getSanskarList().find { it.id == sanskarId }

        if (sanskar != null && sanskar.active) {
            // Check active hours window (e.g. 5 AM to 9 PM)
            if (currentHour in sanskar.startHour..sanskar.endHour) {
                // 1. Acquire temporary WakeLock
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                val wakeLock = pm.newWakeLock(
                    PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                    "MratuBhayas:SanskarWakeLock"
                )
                wakeLock.acquire(15000L)

                // 2. Launch Full-Screen Lock Screen Alarm Activity
                val dismissOpt = prefs.getSanskarDismissOption()
                val fullScreenIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", title)
                    putExtra("TYPE", "SANSKAR")
                    putExtra("DISMISS_OPT", dismissOpt)
                    putExtra("TONE_IDX", 0)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }

                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    (sanskarId + 20000).toInt(),
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // 3. Post Notification
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channelId = "sanskar_channel"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        channelId,
                        "Sanskar Chimes",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Mindful periodic reminder chimes"
                        enableVibration(true)
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                val notification = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("MratuBhayas Sanskar")
                    .setContentText(title)
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setAutoCancel(true)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)
                    .build()

                notificationManager.notify((sanskarId + 20000).toInt(), notification)

                try {
                    context.startActivity(fullScreenIntent)
                } catch (e: Exception) {}
            }

            // Reschedule next occurrence
            prefs.scheduleSanskarAlarm(sanskar)
        }
    }
}
