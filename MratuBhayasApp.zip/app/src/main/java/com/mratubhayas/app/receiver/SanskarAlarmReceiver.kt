package com.mratubhayas.app.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.mratubhayas.app.AlarmAlertActivity
import com.mratubhayas.app.R
import com.mratubhayas.app.audio.NokiaToneEngine
import com.mratubhayas.app.model.AppPreferences
import java.util.*

class SanskarAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("TITLE") ?: "Sanskar Reminder"
        val sanskarId = intent.getLongExtra("SANSKAR_ID", 0L)
        val prefs = AppPreferences(context)

        val sanskar = prefs.getSanskarList().find { it.id == sanskarId }
            ?: prefs.getSanskarList().firstOrNull { it.active }

        if (sanskar != null && sanskar.active) {
            val now = Calendar.getInstance()
            val curMinOfDay = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val startMinOfDay = prefs.getSanskarStartHour() * 60 + prefs.getSanskarStartMinute()
            val endMinOfDay = prefs.getSanskarEndHour() * 60 + prefs.getSanskarEndMinute()

            val inWindow = if (startMinOfDay <= endMinOfDay) {
                curMinOfDay in startMinOfDay..endMinOfDay
            } else {
                curMinOfDay >= startMinOfDay || curMinOfDay <= endMinOfDay
            }

            if (inWindow) {
                // 1. Physically turn on the screen using SCREEN_BRIGHT_WAKE_LOCK
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                @Suppress("DEPRECATION")
                val wakeLock = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                    "MratuBhayas:SanskarWakeLock"
                )
                wakeLock.acquire(15000L)

                val dismissOpt = prefs.getSanskarDismissOption()
                val toneUriStr = prefs.getSanskarToneUri()
                val toneIdx = prefs.getSanskarToneIndex()
                val volume = prefs.getSanskarVolume()
                NokiaToneEngine.volume = volume

                // 2. Play initial chime sound immediately at user's preferred volume
                if (toneUriStr != null) {
                    try {
                        val mp = MediaPlayer().apply {
                            setDataSource(context, Uri.parse(toneUriStr))
                            setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_ALARM)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                                    .build()
                            )
                            setVolume(volume, volume)
                            prepare()
                            start()
                        }
                    } catch (e: Exception) {
                        NokiaToneEngine.playTone(toneIdx, loop = false)
                    }
                } else {
                    NokiaToneEngine.playTone(toneIdx, loop = false)
                }

                // 3. Prepare Full-Screen Lock Screen Alarm Activity
                val fullScreenIntent = Intent(context, AlarmAlertActivity::class.java).apply {
                    putExtra("TITLE", sanskar.title)
                    putExtra("TYPE", "SANSKAR")
                    putExtra("DISMISS_OPT", dismissOpt)
                    putExtra("TONE_URI", toneUriStr)
                    putExtra("TONE_IDX", toneIdx)
                    putExtra("VOLUME", volume)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                }

                val reqCode = (Math.abs(sanskar.id.hashCode()) % 40000) + 20000
                val fullScreenPendingIntent = PendingIntent.getActivity(
                    context,
                    reqCode,
                    fullScreenIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                // 4. Post High Priority Notification with Full Screen Intent (Wakes Lockscreen)
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val channelId = "sanskar_alert_channel_v4"

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val channel = NotificationChannel(
                        channelId,
                        "Sanskar Alerts",
                        NotificationManager.IMPORTANCE_HIGH
                    ).apply {
                        description = "Full screen lockscreen alert for Sanskar reminders"
                        enableVibration(true)
                        vibrationPattern = longArrayOf(0, 500, 200, 500)
                        lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                        setBypassDnd(true)
                    }
                    notificationManager.createNotificationChannel(channel)
                }

                val notification = NotificationCompat.Builder(context, channelId)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle(sanskar.title)
                    .setContentText("संस्कार स्मरण")
                    .setPriority(NotificationCompat.PRIORITY_MAX)
                    .setCategory(NotificationCompat.CATEGORY_ALARM)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    .setAutoCancel(true)
                    .setFullScreenIntent(fullScreenPendingIntent, true)
                    .setContentIntent(fullScreenPendingIntent)
                    .build()

                notificationManager.notify(reqCode, notification)

                try {
                    context.startActivity(fullScreenIntent)
                } catch (e: Exception) {}
            }

            // 5. Always Reschedule Next Interval
            prefs.scheduleSanskarAlarm(sanskar)
        }
    }
}
